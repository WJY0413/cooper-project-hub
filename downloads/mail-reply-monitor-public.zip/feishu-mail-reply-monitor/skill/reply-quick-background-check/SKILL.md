---
name: reply-quick-background-check
description: Quickly review one inbound business-email reply, verify whether it belongs to the outreach thread, and perform a compact public background check on the replying person and company. Use when a polling script or user needs a fail-open notify/suppress decision, especially for high-quality replies that merit fast BD context and a Feishu-ready alert. Do not use for deep due diligence, mailbox mutation, automatic replies, or sending messages directly.
---

# Reply Quick Background Check

Review exactly one candidate email event. Return one machine-readable decision that a lightweight polling script can validate and then use to send a Feishu Bot reminder.

Read `references/reply-review-output.schema.json` before producing the result. Return JSON only and conform to that schema exactly.

## Boundaries

- Default to `decision: notify`. The operating priority is recall: redundant reminders are acceptable; missed human replies are not.
- Suppress only a clear bounce, a pure delivery-status report, a self-sent copy, or an exact duplicate event already processed.
- Treat uncertainty as a reason to notify with a lower confidence, not as a reason to suppress.
- Do not send email, reply to the sender, mark mail read, move mail, edit CRM/database state, or send the Feishu message. The calling script owns side effects.
- Keep this a quick background check. Do not turn it into full company or person due diligence.

## Expected Input

Accept the available subset of this event packet:

- event identity: `event_id`, `message_id`, mailbox, received time
- message: from name/address, reply-to, recipients, subject, plain-text body or snippet
- headers: `In-Reply-To`, `References`, `Auto-Submitted`, `Precedence`, delivery-status fields, list-unsubscribe
- outreach context: original message ID, recipient, company, subject, sent time, quoted-text match
- local hints: Workbench send record, BD database company/contact matches, prior processed-event IDs

Never invent missing fields. Use empty strings, empty arrays, `unknown`, or the closest schema enum when evidence is absent.

## Workflow

### 1. Eliminate only hard non-replies

Set `decision: suppress` only when evidence clearly proves one of these:

- `clear_bounce`: SMTP rejection, non-delivery report, permanent or temporary failure notice
- `delivery_report`: delivery/read receipt with no human or actionable content
- `self_copy`: sender is one of the user's own sending identities and contains no third-party reply
- `exact_duplicate`: the same stable event/message ID was already processed

An out-of-office reply, staff-change notice, ticket acknowledgement, referral, replacement contact, unsubscribe, or substantive negative reply is not a bounce. Notify it; classify it accurately.

### 2. Establish thread and entity relationship

Rank evidence in this order:

1. `In-Reply-To` or `References` matching the original sent message
2. quoted original content, subject continuity, and send-record match
3. sender signature, company domain, website, and original recipient/company context
4. sender wording that clearly responds to the outreach

Do not require the replying address to equal the original recipient. A public mailbox may route the message to an employee, owner, branch, parent company, subsidiary, or related operating entity. Classify that relationship as `same_company`, `related_company`, `unknown`, or `unrelated`; notify unless a hard suppression rule applies.

### 3. Judge reply quality

Set `quality: high` when the reply contains a meaningful commercial signal such as:

- explicit interest, product/pricing/territory question, meeting request, or request for materials
- credible referral or handoff to the responsible person
- concrete business facts, needs, timing, installed base, channel coverage, or decision process
- a reply from a relevant owner, director, buyer, product lead, sales lead, or technical decision maker

Set `quality: normal` for valid but low-information replies, including brief negatives and unsubscribe requests. Use `uncertain` when the content or relationship cannot be resolved quickly.

### 4. Run the micro background check

For a valid reply, especially `quality: high`, spend about 60–120 seconds and stop after enough evidence exists for a practical next action.

1. Check live local authority first when accessible:
   - Workbench send record/thread data
   - local BD company database and known contacts
2. Check current public sources, official first:
   - company website, about/products/contact/team pages
   - official company or person profile
   - company registry, trade association, exhibition, or reputable industry source only when needed
3. Identify the most likely person, role, company, domain, country/region, current business, channel position, and fit with FJD products.
4. Separate confirmed facts from inference. Record concise evidence and confidence.
5. If public lookup fails or takes too long, return `unknown` fields and notify anyway.

Do not claim a role, employer, distributor status, or product fit solely from a name match. Prefer company-domain and thread evidence over ambiguous web results.

### 5. Recommend the next move

Make `recommended_action` immediately usable. Prefer one action, for example: reply today with requested pricing inputs, propose two meeting slots, send the relevant product deck, acknowledge the referral and contact the named person, or process an unsubscribe.

Set urgency:

- `immediate`: explicit meeting/pricing request, time-sensitive opportunity, senior relevant responder, or strong buying signal
- `today`: credible human reply needing a normal business response
- `routine`: administrative, unsubscribe, weak, or uncertain event

### 6. Write the Feishu-ready notification

Keep `notify_text` compact and Chinese-first. Include:

- who replied and from which company
- what they said or asked
- why it matters / BD fit
- recommended next action and urgency
- uncertainty when material

For a suppressed event, keep `notify_text` empty. For any non-suppressed event, always provide it.

## Fail-Open Rule

If local data, public search, a tool, or part of the input is unavailable, do not fail the whole review. Return the best schema-valid JSON available with `decision: notify`, `quality: uncertain`, explicit gaps, and a basic notification. The calling script should also send a basic alert if Codex times out or returns invalid JSON.
