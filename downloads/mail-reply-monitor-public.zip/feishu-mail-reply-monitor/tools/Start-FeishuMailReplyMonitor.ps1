[CmdletBinding()]
param(
    [switch]$Once,
    [switch]$Check,
    [switch]$SendTest,
    [switch]$DryRunNotifications,
    [int]$IntervalSeconds = 0,
    [string]$ReviewFixture = "",
    [string]$ConfigPath = ""
)

$ErrorActionPreference = "Stop"
$workspaceRoot = Split-Path -Parent $PSScriptRoot
$scriptPath = Join-Path $PSScriptRoot "feishu_mail_reply_monitor.py"
if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $ConfigPath = Join-Path $workspaceRoot "feishu_mail_reply_monitor.config.json"
}

$python = Get-Command python -ErrorAction Stop
$arguments = @($scriptPath, "--config", $ConfigPath)
if ($Once) { $arguments += "--once" }
if ($Check) { $arguments += "--check" }
if ($SendTest) { $arguments += "--send-test" }
if ($DryRunNotifications) { $arguments += "--dry-run-notifications" }
if ($IntervalSeconds -gt 0) { $arguments += @("--interval", [string]$IntervalSeconds) }
if (-not [string]::IsNullOrWhiteSpace($ReviewFixture)) {
    $arguments += @("--review-fixture", $ReviewFixture)
}

$env:PYTHONUTF8 = "1"
& $python.Source @arguments
exit $LASTEXITCODE
