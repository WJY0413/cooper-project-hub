[CmdletBinding(SupportsShouldProcess)]
param(
    [ValidateRange(1, 1440)]
    [int]$IntervalMinutes = 5,
    [string]$TaskName = "FeishuMailReplyMonitor"
)

$ErrorActionPreference = "Stop"
$workspaceRoot = Split-Path -Parent $PSScriptRoot
$monitorScript = Join-Path $PSScriptRoot "feishu_mail_reply_monitor.py"
$configPath = Join-Path $workspaceRoot "feishu_mail_reply_monitor.config.json"
$python = (Get-Command python -ErrorAction Stop).Source
$pythonw = Join-Path (Split-Path -Parent $python) "pythonw.exe"
if (-not (Test-Path -LiteralPath $pythonw -PathType Leaf)) {
    $pythonwCommand = Get-Command pythonw -ErrorAction SilentlyContinue
    if ($null -eq $pythonwCommand) {
        throw "未找到 pythonw.exe；无法保证计划任务纯后台无窗口运行。"
    }
    $pythonw = $pythonwCommand.Source
}

& $python $monitorScript --config $configPath --check
if ($LASTEXITCODE -ne 0) {
    throw "飞书 user/bot 身份尚未就绪；请先完成 lark-cli 配置与授权。"
}

$actionArguments = '"{0}" --config "{1}" --once' -f $monitorScript, $configPath
$action = New-ScheduledTaskAction -Execute $pythonw -Argument $actionArguments -WorkingDirectory $workspaceRoot
$trigger = New-ScheduledTaskTrigger `
    -Once `
    -At ((Get-Date).AddMinutes(1)) `
    -RepetitionInterval (New-TimeSpan -Minutes $IntervalMinutes) `
    -RepetitionDuration (New-TimeSpan -Days 3650)
$settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 15) `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -WakeToRun:$false

if ($PSCmdlet.ShouldProcess($TaskName, "注册每 $IntervalMinutes 分钟运行一次的飞书邮箱提醒任务")) {
    Register-ScheduledTask `
        -TaskName $TaskName `
        -Action $action `
        -Trigger $trigger `
        -Settings $settings `
        -Description "纯后台只读检测飞书邮箱新邮件，经 Codex 审查后由飞书 Bot 发送 IM；不会唤醒电脑。" `
        -Force | Out-Null
    Write-Host "已注册任务：$TaskName（每 $IntervalMinutes 分钟，纯后台无窗口）"
}
