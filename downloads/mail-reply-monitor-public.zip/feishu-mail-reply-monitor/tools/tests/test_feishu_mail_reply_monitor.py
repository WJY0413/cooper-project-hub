import json
import logging
from pathlib import Path
import sys
import tempfile
import unittest


TOOLS_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TOOLS_DIR))

from feishu_mail_reply_monitor import (  # noqa: E402
    Config,
    EvidenceLog,
    MailReplyMonitor,
    StateStore,
    fail_open_decision,
    obvious_bounce,
    parse_json_output,
)


def message(message_id: str, subject: str = "Re: Product", body: str = "Can we meet?"):
    return {
        "message_id": message_id,
        "date": "Fri, 17 Jul 2026 12:00:00 +0800",
        "from": "Alice <alice@example.com>",
        "subject": subject,
        "body": body,
    }


class FakeClient:
    def __init__(self, messages, fail_send=False):
        self.messages = messages
        self.fail_send = fail_send
        self.sent = []

    def list_inbox(self):
        return [
            {key: item[key] for key in ("message_id", "date", "from", "subject")}
            for item in self.messages
        ]

    def get_messages(self, message_ids):
        wanted = set(message_ids)
        return [dict(item) for item in self.messages if item["message_id"] in wanted]

    def send_notification(self, text, message_ids, dry_run=False):
        if self.fail_send:
            raise RuntimeError("simulated send failure")
        self.sent.append((text, list(message_ids), dry_run))
        return {"message_id": "om_test"}


class FakeReviewer:
    def __init__(self):
        self.reviewed = []

    def review(self, item):
        self.reviewed.append(item["message_id"])
        result = fail_open_decision(item, "test reviewer")
        result["quality"] = "high"
        result["notify_text"] = "**高质量回复**\n\n建议今天跟进。"
        return result


class MonitorTests(unittest.TestCase):
    def make_monitor(self, temp_dir, client, first_run="baseline"):
        root = Path(temp_dir)
        config = Config(
            recipient_open_id="ou_test",
            mail_profile="mail",
            bot_profile="bot",
            first_run_behavior=first_run,
            state_file=root / "state.json",
            log_file=root / "monitor.log",
            review_log_file=root / "evidence.jsonl",
        )
        logger = logging.getLogger(f"test-{id(client)}")
        logger.handlers.clear()
        logger.addHandler(logging.NullHandler())
        store = StateStore(config.state_file, config.max_seen_ids)
        reviewer = FakeReviewer()
        monitor = MailReplyMonitor(
            config,
            client,
            reviewer,
            store,
            EvidenceLog(config.review_log_file),
            logger,
        )
        return monitor, store, reviewer, config.review_log_file

    def test_parse_json_with_prefix(self):
        value = parse_json_output('notice\n{"messages": [], "count": 0}\n')
        self.assertEqual(value["count"], 0)

    def test_first_run_baselines_without_reading_or_sending(self):
        with tempfile.TemporaryDirectory() as temp:
            client = FakeClient([message("m1")])
            monitor, store, reviewer, _ = self.make_monitor(temp, client)
            result = monitor.poll_once()
            self.assertEqual(result["notified"], 0)
            self.assertEqual(client.sent, [])
            self.assertEqual(reviewer.reviewed, [])
            self.assertEqual(store.load()["seen_message_ids"], ["m1"])

    def test_new_mail_is_reviewed_notified_and_persisted(self):
        with tempfile.TemporaryDirectory() as temp:
            client = FakeClient([message("m1")])
            monitor, store, reviewer, evidence_path = self.make_monitor(temp, client)
            monitor.poll_once()
            client.messages.append(message("m2"))
            result = monitor.poll_once()
            self.assertEqual(result["notified"], 1)
            self.assertEqual(reviewer.reviewed, ["m2"])
            self.assertEqual(client.sent[0][1], ["m2"])
            self.assertIn("m2", store.load()["seen_message_ids"])
            lines = evidence_path.read_text(encoding="utf-8").splitlines()
            self.assertEqual([json.loads(line)["stage"] for line in lines], ["reviewed", "notified"])

    def test_send_failure_does_not_mark_message_seen(self):
        with tempfile.TemporaryDirectory() as temp:
            client = FakeClient([message("m1")])
            monitor, store, _, evidence_path = self.make_monitor(temp, client)
            monitor.poll_once()
            client.messages.append(message("m2"))
            client.fail_send = True
            with self.assertRaises(RuntimeError):
                monitor.poll_once()
            self.assertNotIn("m2", store.load()["seen_message_ids"])
            record = json.loads(evidence_path.read_text(encoding="utf-8").splitlines()[0])
            self.assertEqual(record["stage"], "reviewed")

    def test_obvious_bounce_is_suppressed_without_codex(self):
        with tempfile.TemporaryDirectory() as temp:
            bounce = message(
                "m1",
                "Delivery Status Notification (Failure)",
                "Recipient address rejected. This message is undeliverable.",
            )
            bounce["from"] = "MAILER-DAEMON@example.com"
            client = FakeClient([bounce])
            monitor, store, reviewer, evidence_path = self.make_monitor(
                temp, client, first_run="notify"
            )
            result = monitor.poll_once()
            self.assertEqual(result["suppressed"], 1)
            self.assertEqual(client.sent, [])
            self.assertEqual(reviewer.reviewed, [])
            self.assertIn("m1", store.load()["seen_message_ids"])
            self.assertEqual(
                json.loads(evidence_path.read_text(encoding="utf-8").splitlines()[0])[
                    "decision"
                ]["suppression_reason"],
                "clear_bounce",
            )

    def test_single_auto_reply_marker_is_not_suppressed(self):
        item = message("m1", "Automatic reply: Re: Product", "I am out of office.")
        self.assertFalse(obvious_bounce(item))

    def test_fail_open_notification_omits_body(self):
        item = message("m1", body="private message body")
        result = fail_open_decision(item, "timeout")
        self.assertNotIn("private message body", result["notify_text"])
        self.assertIn("智能审查暂未完成", result["notify_text"])


if __name__ == "__main__":
    unittest.main()
