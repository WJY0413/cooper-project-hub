[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$TaskName = "FeishuMailReplyMonitor"
)

$ErrorActionPreference = "Stop"
$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($null -eq $task) {
    Write-Host "任务不存在：$TaskName"
    exit 0
}

if ($PSCmdlet.ShouldProcess($TaskName, "卸载飞书邮箱回复提醒定时任务")) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "已卸载任务：$TaskName"
}
