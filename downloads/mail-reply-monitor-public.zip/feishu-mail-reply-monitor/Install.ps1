[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RecipientOpenId,
    [Parameter(Mandatory = $true)]
    [string]$MailProfile,
    [Parameter(Mandatory = $true)]
    [string]$BotProfile,
    [ValidateRange(1, 1440)]
    [int]$IntervalMinutes = 5
)

$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
$configPath = Join-Path $projectRoot "feishu_mail_reply_monitor.config.json"
$examplePath = Join-Path $projectRoot "config.example.json"

foreach ($command in @("python", "lark-cli", "codex")) {
    if (-not (Get-Command $command -ErrorAction SilentlyContinue)) {
        throw "缺少命令：$command"
    }
}
if ($RecipientOpenId -notmatch "^ou_") {
    throw "RecipientOpenId 必须是发送消息的 Bot 应用内的 ou_ open_id。"
}

$config = Get-Content -LiteralPath $examplePath -Raw -Encoding UTF8 | ConvertFrom-Json
$config.recipient_open_id = $RecipientOpenId
$config.mail_profile = $MailProfile
$config.bot_profile = $BotProfile
$config | ConvertTo-Json -Depth 20 |
    Set-Content -LiteralPath $configPath -Encoding UTF8

$codexRoot = if ($env:CODEX_HOME) {
    $env:CODEX_HOME
} else {
    Join-Path $env:USERPROFILE ".codex"
}
$skillSource = Join-Path $projectRoot "skill\reply-quick-background-check"
$skillTarget = Join-Path $codexRoot "skills\reply-quick-background-check"
if (Test-Path -LiteralPath $skillTarget) {
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backup = Join-Path $projectRoot "output\backup-$stamp\reply-quick-background-check"
    New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
    Copy-Item -LiteralPath $skillTarget -Destination $backup -Recurse
}
New-Item -ItemType Directory -Path (Split-Path -Parent $skillTarget) -Force | Out-Null
Copy-Item -LiteralPath $skillSource -Destination $skillTarget -Recurse -Force

& (Join-Path $projectRoot "tools\Register-FeishuMailReplyMonitorTask.ps1") `
    -IntervalMinutes $IntervalMinutes
Write-Host "安装完成。配置：$configPath"
