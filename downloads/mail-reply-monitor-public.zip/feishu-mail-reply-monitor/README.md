# 飞书邮箱回复智能提醒器

一个 Windows 本地轻量工具：飞书 CLI 只读检查邮箱，Codex CLI 判断回复质量与主体关系，再由飞书 Bot 给本人发送私聊提醒。

## 特点

- 默认每 5 分钟纯后台运行一次，不弹出窗口，也不唤醒睡眠/关机电脑
- 不标记已读、不移动邮件、不自动回信
- 允许冗余、优先不漏报；只严格过滤明显退信
- 员工从不同地址回复、转介绍、自动回复、负面回复和退订都会提醒
- Codex 失败时 fail-open：先发基础提醒，不让模型故障造成漏报
- 不需要 OpenAI API Key；使用本机已登录的 Codex CLI 权益
- Python 仅使用标准库，无 pip 依赖

## 前置条件

1. Windows 10/11、Python 3.10+（标准安装需包含 `pythonw.exe`）。
2. 已安装并登录 `codex` CLI。
3. 已安装 `lark-cli`。
4. 一个用户 profile：完成 `lark-cli auth login --domain all`，用于只读邮箱。
5. 一个 bot profile：配置 App ID/App Secret，具备 `im:message:send_as_bot`。
6. 接收人的 `ou_...` 必须是该 bot 应用内的 open_id。不同应用的 open_id 不能混用。

飞书应用权限至少包括：

- `mail:user_mailbox.message:readonly`
- `mail:user_mailbox.message.address:read`
- `mail:user_mailbox.message.subject:read`
- `mail:user_mailbox.message.body:read`
- `im:message:send_as_bot`

## 安装

先复制 `config.example.json` 为 `feishu_mail_reply_monitor.config.json` 并填写三项：

- `recipient_open_id`
- `mail_profile`
- `bot_profile`

也可以用安装脚本：

```powershell
.\Install.ps1 `
  -RecipientOpenId "ou_xxx" `
  -MailProfile "your-user-profile" `
  -BotProfile "your-bot-profile" `
  -IntervalMinutes 5
```

安装脚本会复制 Skill、检查身份并注册纯后台、无窗口的 Windows 定时任务。

## 验收

```powershell
python -m unittest discover -s .\tools\tests -p "test_feishu_mail_reply_monitor.py" -v
.\tools\Start-FeishuMailReplyMonitor.ps1 -Check
.\tools\Start-FeishuMailReplyMonitor.ps1 `
  -ReviewFixture .\tools\tests\fixtures\high_quality_staff_reply.json
.\tools\Start-FeishuMailReplyMonitor.ps1 -SendTest
.\tools\Start-FeishuMailReplyMonitor.ps1 -Once
```

首次 `-Once` 默认只建立现有收件箱基线，不提醒历史邮件。之后的新邮件才进入审查与提醒。

## 数据与隐私

- 邮件正文会提交给本机 `codex exec`，用于生成判断。
- 飞书提醒默认只包含总结、主体判断和下一步，不包含完整正文。
- 状态与审查证据只保存在本机 `coo_state/` 和 `output/`。
- 分享包不包含 App Secret、token、真实 open_id、真实邮件、运行日志或客户资料。

## 卸载

```powershell
.\tools\Unregister-FeishuMailReplyMonitorTask.ps1
```

卸载任务不会删除本地状态、日志或 Skill。
