# 分享报告

- 交付物：飞书邮箱回复智能提醒器
- 目标环境：Windows 10/11
- 依赖：Python 3.10+、lark-cli、codex CLI
- 外部副作用：只读邮箱；仅向配置的本人 open_id 发送飞书 Bot 消息
- 不包含：App Secret、OAuth token、Codex token、真实 open_id、真实邮件、客户数据、运行日志
- 测试：Python 单元测试、虚构高质量回复 Codex 实测、真实邮箱只读基线、真实 Bot 私聊、Windows 定时任务实跑
- 已知限制：电脑关机/睡眠时不执行；Codex 使用计入用户现有额度；当前不联网做公开背景调查
