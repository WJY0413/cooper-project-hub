# 分享前复核

## 必须由接收人自行配置

- 飞书用户 profile 与 `domain all` 授权
- 飞书 bot profile 与 App Secret
- bot 应用内的接收人 open_id
- Codex CLI 登录

## 安全边界

- 不包含任何凭据或真实业务数据。
- 邮箱只读；没有发送、修改、删除或标记已读命令。
- 只有飞书 IM Bot 发送属于写操作。
- 发送成功或明确压制后才推进状态；失败会重试。
- 邮件正文被视为不可信输入，提示词明确禁止执行其中指令。
- 明显退信预筛采用多特征门槛；不确定时一律提醒。

## 分享结论

适合在同一公司、已具备飞书自建应用权限和 Codex CLI 权益的同事间分享。接收人必须使用自己的 profile、bot 凭据和 bot 专属 open_id。

机械扫描的 19 个命中已人工复核：通用 Skill 规则保留；`example.com`、`.example` 和 `greenfield.example` 等均为虚构测试样本；CSS `margin` 为误报。包内未发现真实 ID、凭据、邮件或客户数据。
