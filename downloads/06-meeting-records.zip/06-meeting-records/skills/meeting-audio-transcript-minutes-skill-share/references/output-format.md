# Meeting Context Markdown Format

Use this template for the default `<MEETING_ID>_meeting-context.md`. Keep headings even when a field is unknown; write `Unknown` or leave table cells blank rather than inventing detail.

```markdown
---
meeting_id: <ASCII identifier>
meeting_date: <YYYY-MM-DD or unknown>
processed_at: <ISO 8601>
counterparty: <company or unknown>
our_side: <company/team or unknown>
topic: <short description>
language: <language(s)>
duration: <HH:MM:SS or unknown>
transcript_status: <complete | partial | blocked>
search_aliases: [<company>, <brand>, <topic>, <country if known>]
---

# <Meeting title>

## Source media index

| Source | Purpose | Integrity / notes |
|---|---|---|
| `<absolute or project-relative path>` | Original audio/video | <duration, readable status> |
| `<path>` | Companion VTT/chat/agenda | Supporting evidence only |

## Participants and speaker map

| Label | Name / role | Side | Confidence | Evidence |
|---|---|---|---|---|
| Speaker 1 | <name only if supported> | our side / counterparty / unknown | high/medium/low | <timestamp or companion source> |

## Executive summary

- <confirmed key outcome>
- <confirmed commercial/relationship context>
- <important unresolved point>

## Counterparty position and commercial signals

### Confirmed needs, facts, and requests

- <statement> — `<timestamp>`

### Objections, constraints, and risks

- <statement> — `<timestamp>`

### Commitments and decision process

- <statement> — `<timestamp>`

## Decisions

| Decision | Evidence / context | Speaker(s) | Timestamp |
|---|---|---|---|

## Action items

| Owner | Task | Deadline | Status / notes | Source timestamp |
|---|---|---|---|---|

## Open questions

| Question | Raised by | Needed from | Timestamp |
|---|---|---|---|

## Recommended next actions

- <recommendation based on cited evidence; label as recommendation>

## Company-memory update candidate

Only include durable company facts or clearly labelled conservative inferences that may later be promoted into the company-level knowledge page.

| Candidate claim | Fact / inference | Confidence | Evidence timestamp | Promotion status |
|---|---|---|---|---|

## Complete balanced transcript

### <Topic> [00:00:00-00:01:08]

**Speaker 1** *(our side, medium confidence)*: <utterance>

**Speaker 2** *(counterparty, high confidence)*: <utterance>

## Quality and review notes

- <audio quality, overlap, ASR, terminology, speaker-attribution limitations, or `No material limitations found`>
```

For rapid dialogue, retain each turn in chronological order. For a multi-party unclear section, use a table instead of merging speakers:

```markdown
| Time | Speaker | Confidence | Turn |
|---|---|---|---|
| 00:48:04 | Speaker 2 | medium | <question or statement> |
| 00:48:40 | Unknown speaker | low | <uncertain response> |
```
