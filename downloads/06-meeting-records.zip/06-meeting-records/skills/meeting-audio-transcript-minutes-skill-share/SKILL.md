---
name: meeting-audio-transcript-minutes-skill-share
description: Turn a meeting audio or video recording into one searchable Markdown meeting-context record with a complete timestamped transcript, conservative speaker/side attribution, decisions, actions, and source-media index. Use when a user provides or refers to mp3, m4a, mp4, mov, wav, webm, VTT, or Zoom recordings; asks to transcribe a meeting, distinguish speakers, identify each side, extract meeting context, or retain a meeting for later recall.
---

# Meeting Context and Transcript

Create an auditable, retrieval-first meeting record for BD use. The default final deliverable is a single Markdown document, not a bundle of Word and Excel files.

## Default Outcome

For each meeting, create exactly these user-facing files unless the user asks otherwise:

1. `<MEETING_ID>_meeting-context.md` — required, the primary record. It contains the complete timestamped transcript plus structured meeting context.
2. `<MEETING_ID>_quality-report.md` — required only when a material limitation affects trust in the transcript, speaker map, names, figures, or source integrity; otherwise append a short `## Quality and review notes` section to the context document.

Do not generate `.docx`, `.xlsx`, separate speaker summaries, separate non-our-side summaries, grouped transcripts, CSVs, or JSON by default. Generate an Office file only if the user asks for it or a real business handoff requires it:

- `.docx`: shareable formal minutes or a customer/internal review copy;
- `.xlsx`: multiple action owners, decision trackers, or a table the user will actively maintain;
- raw JSON/CSV: only for troubleshooting, reproducibility, or explicit audit request.

Keep the original media unchanged. Index it; do not duplicate it into the knowledge record.

## Output Location and Naming

- Write outputs into a new ASCII-only folder named `<COUNTERPARTY>_<TOPIC>_<YYYYMMDD>` in the user-selected output location.
- Create one meeting context record per recording/session. Merge multiple files only when their order and relationship are clear; otherwise ask.
- Use the spoken language for the transcript. Use the user's language for summaries and context; keep source-language wording where it is material.

## Preflight

1. Locate the supplied media and companion material (`.vtt`, chat export, agenda, participant list). Treat companion text as supporting evidence, never as an unverified replacement for the audio.
2. Inspect file integrity, duration, channels, and language with locally available tools.
3. Detect existing local media and ASR dependencies before using them. Do not install packages, download models, change configuration, call paid/external services, or create more than 2 GB / 3x source-size temporary data without explicit approval.
4. For recordings longer than about 30 minutes, use bounded processing. Default to no more than `min(2, physical_cores - 2)` workers (two if unknown), preserve normal computer responsiveness, and record chunk offsets.

## Transcription and Speaker Rules

1. Produce a complete timestamped transcript. Mark uncertain audio as `[inaudible]`, `[unclear: …]`, or `[overlap]`; never invent wording.
2. Prefer true diarization when already available locally. Otherwise use neutral labels (`Speaker 1`, `Speaker 2`, …) and infer turns conservatively from channel separation, introductions, names used in conversation, and turn-taking.
3. State the side separately from identity: `our side`, `counterparty`, or `unknown`.
4. Assign a real name only when supported by the recording or companion evidence. Record evidence timestamp/file and confidence. Never infer a name from voice alone or company context alone.
5. Preserve rapid dialogue as distinct turns. Merge adjacent same-speaker segments only when this improves reading and does not erase a question, answer, topic shift, decision, objection, or action.
6. Lightly normalize punctuation and paragraphs for reading; do not rewrite business substance or turn inference into fact.

## Required Meeting Context Structure

Read `references/output-format.md` before writing the final context record. It is the canonical template.

The primary Markdown record must contain:

- metadata: meeting identifier, date, processing date, source language, duration, status, and source-media index;
- participant and speaker map with side, confidence, and evidence;
- executive summary for retrieval;
- counterparty position: needs, signals, objections, commitments, decision process, and requests;
- decisions, action items, open questions, risks, and recommended next actions;
- complete balanced transcript with timestamps and conservative speaker labels;
- quality and review notes;
- a `Company-memory update candidate` section: stable reusable company facts/inferences, each with evidence timestamps and confidence. Do not write those claims into a knowledge base unless separately authorized.

Keep fact, inference, and recommended action visibly distinct. For meetings with no clear counterparty, state that rather than forcing a side split.

## Retrieval Design

- Make the context document self-contained so a later search for a company, person, objection, price, project, or decision can land on one file.
- Use clear headings and concise search aliases in the metadata, such as company name, brand, meeting topic, and country where known.
- Do not store raw recordings, credentials, private contact data beyond what is necessary for the business record, or changing queue/send counts in meeting context.
- When maintaining a company-level knowledge page is authorized, link it to the meeting record and promote only stable facts. Preserve the meeting record as the event-level source of truth.

## Validation

Before finishing:

1. Confirm source paths exist and are clearly indexed.
2. Ensure every major topic, decision, and action in the summary is traceable to a transcript timestamp.
3. Verify every named speaker has evidence and confidence; demote unsupported names to neutral labels.
4. Check action items for owner, task, deadline/status, and source timestamp; leave unknown values blank.
5. Flag domain terms, names, numbers, overlap, noise, clipped audio, and suspected ASR repetition that require review.
6. Report the output path, whether the transcript is complete, and material limitations. Do not overstate speaker identification confidence.

## Optional Deliverables

Only on request, create the following from the approved context record:

- `meeting-minutes.docx` for formal sharing;
- `sales-follow-up-brief.docx` for a concise sales brief;
- `meeting-tables.xlsx` for active owner/action tracking;
- separate transcript or speaker files when the meeting is too large for a practical single context record;
- raw segments/JSON/CSV for audit or debugging.

Read the relevant document or spreadsheet skill before creating Office files.

## Review the Workflow

After a real run, create a short `skill_review.md` only when the run exposed a reusable skill issue. Before editing an installed copy, preserve the exact files being changed in a user-selected backup location, then validate the revised skill.

## Startup Intent Line

我将处理会议音视频，输出一份可检索的会议上下文 Markdown：完整带时间戳转录、双方/说话人证据、决策、行动项和原始素材索引。
