# Sender and Company Context Template

Use this template when the user wants to provide company background and identity information for a specific outreach task. The email should use only the parts relevant to the customer, region, and cooperation angle.

## Basic sender identity

- Sender name:
- Title / role:
- Company:
- Business unit / product line:
- Writing identity: sales, overseas BD, country manager, product manager, executive, etc.
- Signature details:

## Company positioning

- One-line company positioning:
- Customer-facing company description:
- Core products / services:
- Main customer types:
- Main cooperation models: distribution, supply partnership, OEM/ODM, project cooperation, strategic partnership, local service/integration, etc.

## Credibility points

List only facts that can be safely used in customer-facing outreach.

- Industry experience:
- Manufacturing / delivery capability:
- Certifications / compliance:
- Existing customer types or project types:
- Market experience:
- Local service / partner support:
- Customization capability:
- Cost / efficiency advantage:

## Region-specific emphasis

Use this to adapt company introduction for different sales regions.

- Europe:
- North America:
- Middle East:
- Southeast Asia:
- Latin America:
- Africa:
- Other named market:

Examples of emphasis:

- Compliance and reliability.
- Local partner support and after-sales capability.
- Cost-effective delivery and customization.
- Technical integration and project coordination.
- Channel development and product portfolio fit.
- Long-term market development.

## Product or scenario focus

- Target product / solution:
- Target customer type:
- Target industry:
- Main customer pain point:
- Most relevant value proposition:
- Desired next step:

## Claims and boundaries

- Claims that are approved to use:
- Claims that must be avoided:
- Confidential information:
- Exact specs, price, warranty, certification, market ranking, or exclusivity that must be verified before use:
