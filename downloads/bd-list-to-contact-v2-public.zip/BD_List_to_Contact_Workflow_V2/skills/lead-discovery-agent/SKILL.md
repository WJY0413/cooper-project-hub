---
name: lead-discovery-agent
description: Discover source-backed B2B distributors, dealers, agents, resellers, service partners, and regional channel targets, dedupe them against the user's BD database, and persist accepted companies directly to the database. Use for regional or industry lead universes, longlists, first-wave queues, association or event mining, brand ecosystems, and market maps. Do not create JSON, JSONL, CSV, Excel, checkpoints, ledgers, or run-summary files unless the user explicitly requests an export or a recovery artifact is required after failure.
---

# Lead Discovery Agent

Build a traceable company universe, select the first wave, and leave the accepted result in BDdb.

## Default Result

Normal completion means:

1. accepted companies and source evidence are recorded in BDdb,
2. duplicates and blacklisted companies are handled,
3. the database is verified,
4. chat receives only a short count-and-risk receipt.

Do not create project process files by default. Do not print full lead records into chat.

## Intake

Infer from the request when clear:

- region and industry,
- target channel role,
- product or buyer scene,
- exclusions,
- desired depth.

Default destination is BDdb. Excel or another file is an explicit export, never a workflow stage.

## Research

Choose the smallest useful source mix:

- official brand dealer/distributor locators,
- trade associations and member directories,
- exhibition lists,
- competitor or reseller networks,
- relevant public directories,
- local-language search,
- user-provided source material.

For each candidate retain, inside the database intake record:

- canonical company name and domain,
- region and channel role,
- concise fit evidence,
- source URL and source type,
- raw alias when it affects dedupe,
- decision: `accepted`, `verify_later`, or `excluded`.

Do not use search failure as exclusion evidence. Keep brand/network seeds separate from contactable companies.

## Database Workflow

1. Load `bd-company-database`.
2. Query SQLite for domain/company matches, blacklist state, and prior source coverage.
3. Hold working candidates in the current process or tool state.
4. Validate accepted records inline.
5. Commit accepted records through the database writer and verify the resulting counts.

If the current compatibility writer technically requires checkpoint JSON, create the minimum adapter under the operating-system temporary directory, use it immediately, and delete it after successful verification. Never place that adapter in the project, present it as a deliverable, or spend chat tokens describing it.

On validation or write failure, roll back. Preserve one compact diagnostic/recovery artifact only when it is needed to resume safely; report its path and reason.

## Quality Gates

- Preserve a source URL for every accepted company.
- Dedupe primarily by normalized domain; treat same-name/different-domain as review, not automatic merge.
- Do not insert blacklisted targets or low-confidence false matches.
- Keep `verify_later` out of the accepted company set.
- Use official-company evidence before DEEP acceptance when practical.
- Do not mark complete until the database write and verification succeed.

## Downstream Routing

- Shortlist scoring: `official-company-shortlist-rating`.
- Groundcare partner background: `groundcare-distributor-background`.
- Official contact routes: `official-contact-research`.
- Deep people/contact work: `company-contact-list-finder`.
- Database persistence and exports: `bd-company-database`.

## Final Response

Report only:

- researched / accepted / existing-updated / new / excluded / unresolved counts,
- database verification result,
- material risks,
- next recommended workflow.

Mention files only when the user requested an export or a failure created a necessary recovery artifact.

