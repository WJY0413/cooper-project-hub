# Database-Native Output Contracts

Use UTF-8 JSONL so discovery work is resumable, auditable, and ready for BDdb intake. Write one object per line. Do not create an Excel/CSV handoff unless the user explicitly requests an export.

## Source Ledger

`source_id, source_lane, source_name, query_or_url, region, coverage_assumption, known_bias, checked_date, notes`

Purpose: prove where the company universe came from and what may be missing.

## Raw Lead Ledger

`raw_id, source_id, raw_company_name, raw_website, raw_location, raw_category, raw_brands, raw_contact_fields_present, raw_notes, source_url, capture_date`

Purpose: preserve source rows before dedupe. Do not delete weak rows silently.

## Dedupe Map

`canonical_company, raw_ids, aliases, primary_website, normalized_domain, region, dedupe_reason, confidence, matched_company_id`

Purpose: keep branch/member/directory variants traceable.

## Company Universe

`company, region, website, normalized_domain, matched_company_id, lead_type, source_lanes, evidence_summary, fit_signal, scale_signal, universe_status, confidence, next_check, source_urls`

Recommended statuses:

- `first_wave_candidate`
- `shortlist_rating_next`
- `dealer_network_seed`
- `ecosystem_or_pilot_resource`
- `review_later`
- `verify_later`
- `backfill_needed`
- `exclude_with_evidence`

## First-Wave Queue

`priority, company, region, website, matched_company_id, why_first_wave, channel_role, product_or_offer_angle, main_risk, next_workflow, source_urls`

Purpose: near-term outreach preparation queue. This is smaller than the longlist.

## Handoff Table

`company, accepted_status, handoff_skill, required_input, evidence_needed, writeback_target, risk_boundary`

Use this before sending targets into rating, contact research, database persistence, mapping, or outreach. Set `writeback_target` to `BDdb` by default.

## BDdb Intake Package

For accepted domain-backed companies, create:

- `checkpoints/<checkpoint_id>.json` using `checkpoint_version=contact_checkpoint_v1`
- `accepted_index.jsonl` with `status=accepted`, `qa_passed=true`, `company_id`, `company_name`, `source_index`, and `checkpoint_path`
- `run_summary.json` with source, accepted, excluded, unresolved, and route counts

Use `private_routes=[]` and `people=[]` when discovery has not yet researched contacts. Preserve the official website under `target.official_website`, discovery evidence under a source-specific object, and the accepted QA basis under `quality_gate`.

Run the database preflight before apply. Excel is available only through an explicit post-database export.
