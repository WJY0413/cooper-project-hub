# Industry Profiles

Industry profiles make Lead Discovery Agent reusable across sectors.

## Profile Contract

Each profile should define:

- `buyer_scenes`: end customers or use cases that prove relevance.
- `channel_types`: distributor, dealer, reseller, installer, integrator, service partner, operator, association, brand seed, or ecosystem player.
- `positive_signals`: evidence that a company belongs in the universe.
- `scale_signals`: branch count, national coverage, service team, installed base, brand portfolio, customer references, certifications, event presence, or procurement footprint.
- `disqualifiers`: categories to exclude or demote with evidence.
- `source_lanes`: high-yield discovery routes.
- `rating_hooks`: what separates first-wave targets from review-later targets.
- `contact_role_hooks`: role types to look for after discovery.
- `terms`: English and local-language keywords.
- `handoff`: preferred downstream skills or workflows.

## Temporary Profile Template

Use this when no durable profile exists:

```text
Industry profile: <name>
Buyer scenes:
Channel types:
Positive signals:
Scale signals:
Disqualifiers:
Source lanes:
First-wave hooks:
Contact-role hooks:
Local-language terms:
Downstream handoff:
Open assumptions:
```

## Open-Source Rule

Keep profiles industry-generic. Do not bake in private company strategy, confidential product details, or user-only identity. Put user-specific context in the run intake, not in the reusable profile.

## Switching Industries

When the industry is not groundcare:

1. Draft or load the industry profile first.
2. Replace product/customer keywords before searching.
3. Replace disqualifiers before excluding companies.
4. Keep the same discovery mechanics: source plan, raw ledger, dedupe, longlist, first-wave queue, handoff.
5. Label assumptions that need the user's confirmation.
