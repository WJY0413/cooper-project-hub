# Groundcare Profile

Default profile for robotic mower, line-marking robot, and turf automation BD.

## Buyer Scenes

- golf courses and golf course maintenance
- sports turf, stadiums, schools, universities, and clubs
- local authorities, municipalities, parks, and public green-space teams
- grounds maintenance contractors and landscapers
- estates, resorts, campuses, facilities, and commercial properties
- professional garden machinery and rural-property customers

## Channel Types

- groundcare, turf-care, and commercial mower distributors
- garden machinery and professional outdoor power equipment dealers
- agricultural machinery dealers with groundcare, compact tractor, mower, ATV/UTV, estate, or municipal overlap
- robotic mower dealers, installers, and service partners
- sports turf, golf, irrigation, construction, or turf-maintenance ecosystem players
- brand-side dealer-network seeds when their dealer locator can expose downstream targets
- associations, exhibitions, directories, and buying groups that reveal the market universe

## Positive Signals

- sells or services commercial mowers, robotic mowers, ride-on mowers, turf machinery, groundcare equipment, compact tractors, line-marking, irrigation, or sports-field equipment
- has workshop, parts, mobile service, hire, demo, training, installation, or multi-branch support
- represents premium or relevant brands such as Toro, John Deere, Kubota, Jacobsen, Dennis, SISIS, Campey, Redexim, AS-Motor, SABO, EGO, Kress, Husqvarna, Ambrogio, Belrobotics, or similar
- serves golf, sports turf, municipal, contractor, school, estate, or commercial landscape customers
- appears in a trade association, dealer locator, exhibitor list, or official distributor network with relevant category labels

## Scale Signals

- national or regional coverage
- multiple depots, branches, service vans, or dealer network
- official distributor/importer status
- visible service/parts capability
- repeated event presence or trade media mentions
- named commercial, groundcare, turf, robotics, service, or branch managers

## Disqualifiers And Demotions

- generic online retailer with no professional customer or service evidence
- small local garden shop with only consumer lawn/garden retail
- artificial turf-only supplier with no maintenance/equipment/channel role
- consultancy, design-only, media, or training organization with no channel path
- manufacturer with no third-party channel need unless it is useful as a dealer-network seed
- low relevance may be `exclude` only when the evidence clearly supports it; sparse data is `verify_later`

## Source Lanes

- trade associations: BAGMA, dealer groups, national turf/grounds associations, local equivalents
- exhibitions: SALTEX, BTME, GroundsFest, regional turf/greenkeeping shows, garden machinery shows
- brand locators: mower, robotics, turf equipment, compact tractor, and line-marking brands
- industry directories: groundcare, garden machinery, golf/turf suppliers, sports turf suppliers
- competitor and complementary brand partner pages
- local-language queries for turf equipment, mower dealer, groundcare distributor, golf course equipment, robotic mower installer, line marking machine supplier, municipal grounds maintenance equipment
- official websites of known regional players, then their brands, branches, and dealer links

## First-Wave Hooks

Prioritize companies with:

- strong channel/customer overlap plus service capability
- commercial or professional customer base
- robotics, mower, line-marking, turf, golf, municipal, or contractor relevance
- regional coverage or brand authority
- a plausible low-conflict cooperation angle
- enough public evidence for downstream contact research

Demote companies with:

- weak professional overlap
- unclear service capability
- pure retail/e-commerce orientation
- heavy brand conflict with no complementary angle
- missing official website that still needs backfill

## Contact Role Hooks

After discovery, target:

- owner, founder, managing director, director
- sales director, business development, commercial manager
- groundcare, turf, golf, robotics, mower, product, category, or branch manager
- service, parts, hire, or aftersales manager when the cooperation angle depends on service capacity
- official general sales/contact route when named decision makers are not public

## Handoff

- Company shortlist: `official-company-shortlist-rating`
- Groundcare report or Chinese workbook: `groundcare-distributor-background`
- Large workbook screening: `large-bd-table-rating`
- Official-site profiles: `official-website-profile-batch-rating`
- Contact routes: `official-contact-research` or `public-business-contact-mining`
- Decision makers: `company-key-people-mapper` or `company-person-background-check`
