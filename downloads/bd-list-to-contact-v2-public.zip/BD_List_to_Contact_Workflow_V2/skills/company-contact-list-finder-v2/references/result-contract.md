# Canonical contact-mining result

Return one `contact-mining-result/v1` object. This is a neutral research result,
not a database or workbook write instruction.

## Required top-level fields

```text
schema_version
result_id
run_id
work_item_id
supersedes_result_id
entity
workflow_binding
rating_context
requested_depth
execution
completion
depths
decision_maker_search
people
routes
searched_families
rejected_candidates
baseline_comparison
quality_gate
summary
source_skill_chain
input_sha256
result_sha256
```

Compute `result_sha256` from canonical UTF-8 JSON after removing
`result_id` and `result_sha256`. Set:

```text
result_id = "cmres_" + result_sha256[:24]
```

## Depth status and outcome

Final depth status:

- `not_requested`
- `completed`
- `review`
- `failed`

Final route outcome:

- `not_applicable`
- `person_route_found`
- `company_route_only`
- `no_route_exhausted`
- `ambiguous_needs_review`
- `blocked`
- `technical_failure`

Required mappings:

- `completed` -> `person_route_found|company_route_only|no_route_exhausted`
- `review` -> `ambiguous_needs_review|blocked`
- `failed` -> `technical_failure`
- `not_requested` -> `not_applicable`

`completion.light_completed` and `completion.deep_completed` are derived from
depth status. Deep completion always implies light completion.

## People

Each retained person must include:

```text
person_ref
person_id
name
title
role_evidence
person_backcheck_status
linkedin_search_status
contact_research_status
contact_research_notes
```

Keep `title` as the clean current company role. Put source proof in
`role_evidence`. If no named person is retained, require:

```text
decision_maker_search.level = enhanced
decision_maker_search.status = no_named_person_after_enhanced_search
```

For light, set
`person_backcheck_status=official_only_completed` and
`linkedin_search_status=not_requested_light`; light must not actively search
LinkedIn or other deep-only source families. Deep requires
`person_backcheck_status=completed` plus a terminal LinkedIn status.

## Routes

Use a single route array with explicit scope.

Approved `scope`:

- `company`
- `person`

Approved `type`:

- `email`
- `phone`
- `whatsapp`
- `contact_form`
- `linkedin_profile`
- `company_linkedin`
- `named_official_route`
- `other`

Approved `verification`:

- `public_confirmed`
- `inferred`
- `ambiguous`
- `rejected`

Approved `confidence`:

- `high`
- `medium`
- `low`

Approved `use_case`:

- `first_outreach`
- `verification`
- `fallback`
- `do_not_use`

Only `public_confirmed` may be treated as a usable route. Inferred, ambiguous,
pattern-only, stale, weak, or rejected candidates must use
`use_case=do_not_use`. A person route must reference a retained `person_ref`; a
company route must not be attached to a person.

Every route retains its source URL, evidence note, observed timestamp, raw
value, normalized value, `discovered_depth=light|deep`, source family, and
confidence. Email routes also retain `email_risk` and `email_basis`.

## Source-family terminal states

Use:

- `found`
- `checked_no_route`
- `blocked`
- `not_applicable`

A found family needs an evidence URL. A blocked or not-applicable family needs
a reason. A checked-no-route family needs a query or URL proving what was
checked.

Light requires terminal official-site family coverage. Deep additionally
requires terminal registry/legal, procurement/vendor,
association/member, exhibition/event, trade/partner, business-directory,
public-social/LinkedIn, email-pattern, and public-messenger coverage.

## Quality

Approved quality result:

- `pass`
- `review`
- `fail`

Approved pass basis:

- `light_official_research_complete`
- `verified_person_route_improved`
- `strict_research_exhausted`

`execution.status=completed` requires `quality_gate.result=pass` and a
completed light depth. `review` maps to quality review; `failed` maps to
quality fail.

Do not use a contactability A/B/C field. Preserve the upstream company rating
unchanged and, if needed, use the non-conflicting name `route_quality_grade`
inside `summary`.
