# Contact-mining work-item contract

Use one `contact-mining-work-item/v1` object for one already-assigned company.
The professional packaging/controller layer owns assignment and scheduling.

## Required object

```json
{
  "schema_version": "contact-mining-work-item/v1",
  "work_item_id": "cmwi_example",
  "entity": {
    "entity_type": "company",
    "entity_id": "resolver-issued-stable-company-id",
    "company_name": "Example Ltd",
    "official_website": "https://example.com",
    "normalized_domain": "example.com"
  },
  "workflow_binding": {
    "stage": "contact_mining",
    "status": "pending",
    "revision": 1,
    "current_tag_id": "wft_example"
  },
  "rating_context": {
    "rating": "B+",
    "rating_result_id": "rating-result-id",
    "authorized_for_contact_mining": true
  },
  "requested_depth": "light",
  "research_context": {
    "country_code": "GB",
    "search_language_mode": "en",
    "bizseek_enabled": true,
    "source_people": [],
    "company_clues": [],
    "baseline_routes": []
  },
  "issued_at": "2026-07-30T00:00:00Z",
  "input_sha256": "64-lowercase-hex"
}
```

Compute `input_sha256` from canonical UTF-8 JSON after removing the
`input_sha256` field. Canonical JSON uses sorted keys and compact separators.

## Fixed rules

- Accept ratings `A+`, `A`, `A-`, `B+`, or `B`.
- Require `authorized_for_contact_mining=true`; never infer eligibility.
- Require a resolver-issued company ID. Reject company name, domain, LinkedIn
  person ID, or raw-card ID used as the entity key.
- Require the active workflow stage to be `contact_mining`.
- Accept input status `pending`, `running`, or `review`. Do not accept
  `completed`, `failed`, or `stopped` as a fresh mining assignment.
- Accept `requested_depth=light|deep` only with the future Stage-7 rating lane:
  `A+`, `A`, `A-`, and `B+` require `deep`; `B` requires `light`.
- Treat the supplied rating, tag, revision, country, language, and
  table-level BizSeek decision as immutable.
- Preserve source people and clues as input evidence; do not silently promote
  them to verified employees or company identity.

## Explicitly excluded control fields

Reject top-level queue, shard, worker, thread, release, callback,
`next_company`, workbook-writeback, and destination-write fields. A simple
opaque `assignment_ref` may be included for traceability, but V2 must never act
on it.
