# Research-preservation gate

Preserve these old-workflow effects while removing its controller and
writeback behavior.

## Light gate

1. Confirm official company identity and domain.
2. Check applicable homepage/footer, contact, about/legal, team/people,
   locations/branches, sales, service, and parts pages.
3. Search person-bearing official pages before accepting a generic route.
4. Preserve direct evidence and blocked/no-route pages.
5. Never call the DB commit path of `official-contact-research`.
6. Do not search LinkedIn, registries, directories, trade sources, or other
   deep-only families.

## Deep gate

1. Complete light.
2. Check registry/legal evidence and same-name/acquisition risk.
3. Map owner/founder/MD/director before secondary commercial or service roles.
4. Backcheck every retained person and verify the current company role.
5. Run public third-party source families and person-specific lanes.
6. Search exact personal LinkedIn and keep company LinkedIn separate.
7. Continue until each applicable family is terminal.
8. Keep public-confirmed, inferred, ambiguous, stale, and rejected candidates
   separate.

## Enhanced decision-maker gate

When the normal pass finds no named person, expand registry, official
documents, local-language pages, LinkedIn/public social, association,
exhibition, trade-media, partner/dealer, and directory searches. A
company-route-only result cannot pass without this evidence.

## Two-layer QA

Layer 1 passes only on a verified named-person route improvement against the
supplied baseline.

When Layer 1 does not pass:

- light may pass after complete official-site coverage;
- deep may pass only after strict source-family and person-lane exhaustion.

Allow one focused repair for the same company. Return review/failure after the
repair if required coverage or evidence remains incomplete.
