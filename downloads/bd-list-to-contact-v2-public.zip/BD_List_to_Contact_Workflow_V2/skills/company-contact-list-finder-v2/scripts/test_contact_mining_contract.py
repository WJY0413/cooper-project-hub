from __future__ import annotations

import copy
import unittest

from contact_mining_contract import (
    LIGHT_SOURCE_FAMILIES,
    seal_result,
    seal_work_item,
    validate_result,
    validate_work_item,
)


NOW = "2026-07-30T00:00:00Z"


def valid_work_item(depth: str = "light", rating: str = "B") -> dict:
    return seal_work_item(
        {
            "schema_version": "contact-mining-work-item/v1",
            "work_item_id": "cmwi_example_001",
            "entity": {
                "entity_type": "company",
                "entity_id": "lrawc_example0001",
                "company_name": "Example Groundcare Ltd",
                "official_website": "https://example.com",
                "normalized_domain": "example.com",
            },
            "workflow_binding": {
                "stage": "contact_mining",
                "status": "running",
                "revision": 1,
                "current_tag_id": "wft_example0001",
            },
            "rating_context": {
                "rating": rating,
                "rating_result_id": "rating_example_001",
                "authorized_for_contact_mining": True,
            },
            "requested_depth": depth,
            "research_context": {
                "country_code": "GB",
                "search_language_mode": "en",
                "bizseek_enabled": True,
                "source_people": [],
                "company_clues": [],
                "baseline_routes": [],
            },
            "issued_at": NOW,
        }
    )


def family_rows(families: set[str], depth: str = "light") -> list[dict]:
    return [
        {
            "family": family,
            "depth": "light" if family.startswith("official_") else depth,
            "status": "checked_no_route",
            "query_or_url": f"https://example.com/check/{family}",
            "evidence_url": None,
            "reason": None,
            "notes": "Checked.",
        }
        for family in sorted(families)
    ]


def valid_light_result() -> dict:
    work_item = valid_work_item()
    payload = {
        "schema_version": "contact-mining-result/v1",
        "result_id": "",
        "run_id": "cmrun_example_001",
        "work_item_id": work_item["work_item_id"],
        "supersedes_result_id": None,
        "entity": {
            **work_item["entity"],
            "country_code": "GB",
        },
        "workflow_binding": work_item["workflow_binding"],
        "rating_context": work_item["rating_context"],
        "requested_depth": "light",
        "execution": {
            "skill": "company-contact-list-finder-v2",
            "skill_version": "0.1.0-design",
            "status": "completed",
            "started_at": NOW,
            "completed_at": NOW,
        },
        "completion": {
            "light_completed": True,
            "deep_completed": False,
        },
        "depths": {
            "light": {
                "status": "completed",
                "route_outcome": "person_route_found",
                "coverage_complete": True,
                "notes": "Official-site lane completed.",
            },
            "deep": {
                "status": "not_requested",
                "route_outcome": "not_applicable",
                "coverage_complete": False,
                "notes": "Deep was not requested.",
            },
        },
        "decision_maker_search": {
            "level": "standard",
            "status": "named_person_found",
            "evidence_notes": "Managing Director confirmed on official team page.",
            "sources": ["https://example.com/team"],
        },
        "people": [
            {
                "person_ref": "person_001",
                "person_id": None,
                "name": "Alex Example",
                "title": "Managing Director",
                "role_evidence": "Official team page.",
                "person_backcheck_status": "official_only_completed",
                "linkedin_search_status": "not_requested_light",
                "contact_research_status": "person_route_found",
                "contact_research_notes": "Direct work email published.",
            }
        ],
        "routes": [
            {
                "route_id": "route_001",
                "scope": "person",
                "person_ref": "person_001",
                "type": "email",
                "raw_value": "alex@example.com",
                "normalized_value": "alex@example.com",
                "discovered_depth": "light",
                "verification": "public_confirmed",
                "confidence": "high",
                "use_case": "first_outreach",
                "source_family": "official_site_people",
                "source_url": "https://example.com/team",
                "evidence_note": "Published next to Alex Example.",
                "observed_at": NOW,
                "email_risk": "low",
                "email_basis": "official_published",
            }
        ],
        "searched_families": family_rows(LIGHT_SOURCE_FAMILIES),
        "rejected_candidates": [],
        "baseline_comparison": {
            "baseline_source": "none",
            "baseline_verified_person_route_count": 0,
            "current_verified_person_route_count": 1,
            "private_route_delta": 1,
            "layer1_result": "pass",
        },
        "quality_gate": {
            "result": "pass",
            "pass_basis": "light_official_research_complete",
            "strict_research_audit_complete": False,
            "issues": [],
            "checked_at": NOW,
        },
        "summary": {
            "verified_person_route_count": 1,
            "verified_company_route_count": 0,
            "inferred_candidate_count": 0,
        },
        "source_skill_chain": [
            "company-contact-list-finder-v2",
            "official-contact-research:research-rules-only",
        ],
        "input_sha256": work_item["input_sha256"],
        "result_sha256": "",
    }
    return seal_result(payload)


class WorkItemTests(unittest.TestCase):
    def test_valid_work_item(self) -> None:
        self.assertEqual(validate_work_item(valid_work_item()), [])

    def test_queue_control_is_rejected(self) -> None:
        payload = valid_work_item()
        payload["next_company"] = "Another Ltd"
        payload = seal_work_item(payload)
        errors = validate_work_item(payload)
        self.assertTrue(any("forbidden" in error for error in errors))

    def test_c_rating_is_rejected(self) -> None:
        payload = valid_work_item()
        payload["rating_context"]["rating"] = "C"
        payload = seal_work_item(payload)
        errors = validate_work_item(payload)
        self.assertTrue(any("rating_context.rating" in error for error in errors))

    def test_rating_depth_lane_is_enforced(self) -> None:
        priority = valid_work_item("light", "B+")
        errors = validate_work_item(priority)
        self.assertTrue(any("must be deep" in error for error in errors))
        b_deep = valid_work_item("deep", "B")
        errors = validate_work_item(b_deep)
        self.assertTrue(any("must be light for B" in error for error in errors))


class ResultTests(unittest.TestCase):
    def test_valid_light_result(self) -> None:
        self.assertEqual(validate_result(valid_light_result()), [])

    def test_deep_cannot_complete_without_light(self) -> None:
        payload = valid_light_result()
        payload["requested_depth"] = "deep"
        payload["completion"] = {
            "light_completed": False,
            "deep_completed": True,
        }
        payload["depths"]["light"]["status"] = "review"
        payload["depths"]["light"]["route_outcome"] = "blocked"
        payload["depths"]["deep"]["status"] = "completed"
        payload["depths"]["deep"]["route_outcome"] = "person_route_found"
        payload = seal_result(payload)
        errors = validate_result(payload)
        self.assertTrue(
            any("deep_completed=true requires light_completed=true" in e for e in errors)
        )

    def test_inferred_route_cannot_be_usable(self) -> None:
        payload = valid_light_result()
        payload["routes"][0]["verification"] = "inferred"
        payload = seal_result(payload)
        errors = validate_result(payload)
        self.assertTrue(
            any("non-confirmed route must use use_case=do_not_use" in e for e in errors)
        )

    def test_hash_tamper_is_rejected(self) -> None:
        payload = valid_light_result()
        payload["entity"]["company_name"] = "Changed Ltd"
        errors = validate_result(payload)
        self.assertTrue(any("result_sha256 does not match" in e for e in errors))

    def test_no_person_completion_requires_enhanced_search(self) -> None:
        payload = valid_light_result()
        payload["people"] = []
        payload["routes"] = []
        payload["depths"]["light"]["route_outcome"] = "no_route_exhausted"
        payload["baseline_comparison"][
            "current_verified_person_route_count"
        ] = 0
        payload["baseline_comparison"]["private_route_delta"] = 0
        payload["baseline_comparison"]["layer1_result"] = "no_improvement"
        payload = seal_result(payload)
        errors = validate_result(payload)
        self.assertTrue(
            any("enhanced no-named-person search" in e for e in errors)
        )

    def test_light_rejects_linkedin_search_expansion(self) -> None:
        payload = valid_light_result()
        payload["people"][0][
            "linkedin_search_status"
        ] = "searched_no_public_linkedin"
        payload["searched_families"].append(
            {
                "family": "public_social_linkedin",
                "depth": "light",
                "status": "checked_no_route",
                "query_or_url": "Alex Example LinkedIn search",
                "evidence_url": None,
                "reason": None,
                "notes": "No result.",
            }
        )
        payload = seal_result(payload)
        errors = validate_result(payload)
        self.assertTrue(
            any("not_requested_light" in error for error in errors)
        )
        self.assertTrue(
            any("deep-only in a light result" in error for error in errors)
        )


if __name__ == "__main__":
    unittest.main()
