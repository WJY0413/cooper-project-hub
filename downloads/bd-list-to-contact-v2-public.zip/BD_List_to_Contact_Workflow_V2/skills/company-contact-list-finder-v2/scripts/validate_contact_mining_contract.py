from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from contact_mining_contract import (
    computed_result_sha256,
    computed_work_item_sha256,
    load_json_object,
    validate_result,
    validate_work_item,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Validate one contact-mining work item or canonical result."
    )
    parser.add_argument("kind", choices=("work-item", "result"))
    parser.add_argument("input", type=Path)
    parser.add_argument(
        "--show-computed-hash",
        action="store_true",
        help="Include the canonical computed hash in the JSON report.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        payload = load_json_object(args.input)
        if args.kind == "work-item":
            errors = validate_work_item(payload)
            digest = computed_work_item_sha256(payload)
        else:
            errors = validate_result(payload)
            digest = computed_result_sha256(payload)
        report = {
            "kind": args.kind,
            "input": str(args.input.resolve()),
            "valid": not errors,
            "error_count": len(errors),
            "errors": errors,
        }
        if args.show_computed_hash:
            report["computed_sha256"] = digest
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if not errors else 1
    except Exception as exc:
        print(
            json.dumps(
                {
                    "kind": args.kind,
                    "input": str(args.input),
                    "valid": False,
                    "error_count": 1,
                    "errors": [str(exc)],
                },
                ensure_ascii=False,
                indent=2,
            ),
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
