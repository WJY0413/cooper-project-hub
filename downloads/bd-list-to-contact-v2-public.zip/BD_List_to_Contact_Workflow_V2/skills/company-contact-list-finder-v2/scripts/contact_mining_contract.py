from __future__ import annotations

import copy
import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


WORK_ITEM_SCHEMA = "contact-mining-work-item/v1"
RESULT_SCHEMA = "contact-mining-result/v1"

ELIGIBLE_RATINGS = {"A+", "A", "A-", "B+", "B"}
REQUESTED_DEPTHS = {"light", "deep"}
# LinkedIn Stage 8 has two non-interchangeable lanes.  Keep this in the
# machine contract so a controller cannot accidentally turn a B company into
# an expensive deep run, or accept a light result for a priority company.
DEEP_REQUIRED_RATINGS = {"A+", "A", "A-", "B+"}
LIGHT_REQUIRED_RATINGS = {"B"}
INPUT_WORKFLOW_STATUSES = {"pending", "running", "review"}
FINAL_STATUSES = {"completed", "review", "failed"}
DEPTH_STATUSES = {"not_requested", "completed", "review", "failed"}
DEPTH_OUTCOMES = {
    "not_applicable",
    "person_route_found",
    "company_route_only",
    "no_route_exhausted",
    "ambiguous_needs_review",
    "blocked",
    "technical_failure",
}
OUTCOMES_BY_STATUS = {
    "not_requested": {"not_applicable"},
    "completed": {
        "person_route_found",
        "company_route_only",
        "no_route_exhausted",
    },
    "review": {"ambiguous_needs_review", "blocked"},
    "failed": {"technical_failure"},
}

ROUTE_SCOPES = {"company", "person"}
ROUTE_TYPES = {
    "email",
    "phone",
    "whatsapp",
    "contact_form",
    "linkedin_profile",
    "company_linkedin",
    "named_official_route",
    "other",
}
ROUTE_VERIFICATIONS = {
    "public_confirmed",
    "inferred",
    "ambiguous",
    "rejected",
}
CONFIDENCE_BANDS = {"high", "medium", "low"}
ROUTE_USE_CASES = {"first_outreach", "verification", "fallback", "do_not_use"}
EMAIL_RISKS = {"low", "medium", "high", "unknown"}
EMAIL_BASES = {
    "official_published",
    "third_party_public",
    "pattern_only",
    "other",
}

SOURCE_FAMILY_STATUSES = {
    "found",
    "checked_no_route",
    "blocked",
    "not_applicable",
}
LIGHT_SOURCE_FAMILIES = {
    "official_site_home",
    "official_site_contact",
    "official_site_people",
    "official_site_locations",
    "official_site_department",
}
DEEP_SOURCE_FAMILIES = LIGHT_SOURCE_FAMILIES | {
    "registry_legal",
    "procurement_vendor",
    "association_member",
    "exhibition_event",
    "trade_media_partner",
    "business_directory",
    "public_social_linkedin",
    "email_pattern",
    "public_messenger",
}

PERSON_BACKCHECK_STATUSES = {
    "official_only_completed",
    "completed",
    "needs_review",
    "blocked",
}
LINKEDIN_SEARCH_STATUSES = {
    "found_personal_linkedin",
    "searched_no_public_linkedin",
    "ambiguous_needs_review",
    "not_requested_light",
}
CONTACT_RESEARCH_STATUSES = {
    "person_route_found",
    "linkedin_only",
    "searched_no_person_route",
    "needs_manual_review",
}
DECISION_LEVELS = {"standard", "enhanced"}
DECISION_STATUSES = {
    "named_person_found",
    "no_named_person_after_enhanced_search",
    "needs_review",
}
QUALITY_RESULTS = {"pass", "review", "fail"}
QUALITY_PASS_BASES = {
    "light_official_research_complete",
    "verified_person_route_improved",
    "strict_research_exhausted",
}

EXCLUDED_CONTROL_KEYS = {
    "queue",
    "queue_state",
    "shard",
    "worker",
    "worker_thread_id",
    "thread_id",
    "release_token",
    "callback",
    "callback_path",
    "self_message",
    "next_company",
    "NEXT_COMPANY_READY",
    "source_workbook",
    "active_workbook",
    "destination",
    "destination_path",
    "writeback",
}

HEX_64 = re.compile(r"^[0-9a-f]{64}$")
COUNTRY_CODE = re.compile(r"^[A-Z]{2}$")


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def computed_work_item_sha256(payload: dict[str, Any]) -> str:
    canonical = copy.deepcopy(payload)
    canonical.pop("input_sha256", None)
    return sha256_text(canonical_json(canonical))


def computed_result_sha256(payload: dict[str, Any]) -> str:
    canonical = copy.deepcopy(payload)
    canonical.pop("result_id", None)
    canonical.pop("result_sha256", None)
    return sha256_text(canonical_json(canonical))


def seal_work_item(payload: dict[str, Any]) -> dict[str, Any]:
    sealed = copy.deepcopy(payload)
    sealed["input_sha256"] = computed_work_item_sha256(sealed)
    return sealed


def seal_result(payload: dict[str, Any]) -> dict[str, Any]:
    sealed = copy.deepcopy(payload)
    digest = computed_result_sha256(sealed)
    sealed["result_sha256"] = digest
    sealed["result_id"] = "cmres_" + digest[:24]
    return sealed


def load_json_object(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8-sig").strip()
    if not text:
        raise ValueError(f"empty JSON input: {path}")
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        lines = [line for line in text.splitlines() if line.strip()]
        if len(lines) != 1:
            raise
        payload = json.loads(lines[0])
    if not isinstance(payload, dict):
        raise ValueError("top-level JSON value must be an object")
    return payload


def _is_text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _is_http_url(value: Any) -> bool:
    if not _is_text(value):
        return False
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def _is_utc_rfc3339(value: Any) -> bool:
    if not _is_text(value):
        return False
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return False
    return parsed.tzinfo is not None and parsed.utcoffset().total_seconds() == 0


def _parse_rfc3339(value: str) -> datetime:
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    return datetime.fromisoformat(normalized)


def _mapping(
    payload: dict[str, Any], key: str, errors: list[str]
) -> dict[str, Any]:
    value = payload.get(key)
    if not isinstance(value, dict):
        errors.append(f"{key} must be an object")
        return {}
    return value


def _array(payload: dict[str, Any], key: str, errors: list[str]) -> list[Any]:
    value = payload.get(key)
    if not isinstance(value, list):
        errors.append(f"{key} must be an array")
        return []
    return value


def _require_text(
    payload: dict[str, Any], key: str, prefix: str, errors: list[str]
) -> str:
    value = payload.get(key)
    if not _is_text(value):
        errors.append(f"{prefix}.{key} must be non-empty text")
        return ""
    return str(value).strip()


def _require_choice(
    payload: dict[str, Any],
    key: str,
    allowed: set[str],
    prefix: str,
    errors: list[str],
) -> str:
    value = _require_text(payload, key, prefix, errors)
    if value and value not in allowed:
        errors.append(
            f"{prefix}.{key} must be one of {sorted(allowed)}, found {value!r}"
        )
    return value


def _validate_common_entity(
    payload: dict[str, Any], prefix: str, errors: list[str]
) -> None:
    entity_type = _require_choice(
        payload, "entity_type", {"company"}, prefix, errors
    )
    entity_id = _require_text(payload, "entity_id", prefix, errors)
    company_name = _require_text(payload, "company_name", prefix, errors)
    website = _require_text(payload, "official_website", prefix, errors)
    domain = _require_text(payload, "normalized_domain", prefix, errors)
    if website and not _is_http_url(website):
        errors.append(f"{prefix}.official_website must be an http(s) URL")
    if domain and (
        "://" in domain
        or "/" in domain
        or domain != domain.lower()
        or domain.startswith(".")
    ):
        errors.append(
            f"{prefix}.normalized_domain must be a lowercase bare domain"
        )
    if entity_type == "company" and entity_id:
        if entity_id in {company_name, domain, website}:
            errors.append(f"{prefix}.entity_id must be a stable resolver ID")
        if entity_id.startswith(("lrawp_", "raw_card", "http://", "https://")):
            errors.append(
                f"{prefix}.entity_id must not be a person, raw-card, or URL key"
            )
        if len(entity_id) < 8:
            errors.append(f"{prefix}.entity_id is too short for a stable ID")


def _validate_workflow_binding(
    payload: dict[str, Any], prefix: str, errors: list[str]
) -> None:
    _require_choice(payload, "stage", {"contact_mining"}, prefix, errors)
    _require_choice(
        payload, "status", INPUT_WORKFLOW_STATUSES, prefix, errors
    )
    revision = payload.get("revision")
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
        errors.append(f"{prefix}.revision must be an integer >= 1")
    current_tag_id = _require_text(
        payload, "current_tag_id", prefix, errors
    )
    if current_tag_id and not current_tag_id.startswith("wft_"):
        errors.append(f"{prefix}.current_tag_id must start with wft_")


def _validate_rating_context(
    payload: dict[str, Any], prefix: str, errors: list[str]
) -> None:
    _require_choice(payload, "rating", ELIGIBLE_RATINGS, prefix, errors)
    _require_text(payload, "rating_result_id", prefix, errors)
    if payload.get("authorized_for_contact_mining") is not True:
        errors.append(
            f"{prefix}.authorized_for_contact_mining must be true"
        )


def _validate_rating_depth(
    rating: dict[str, Any], requested_depth: str, prefix: str, errors: list[str]
) -> None:
    """Enforce the Stage-8 rating-to-depth routing on work items and results."""
    rating_value = rating.get("rating")
    if rating_value in DEEP_REQUIRED_RATINGS and requested_depth != "deep":
        errors.append(
            f"{prefix}.requested_depth must be deep for priority rating {rating_value}"
        )
    if rating_value in LIGHT_REQUIRED_RATINGS and requested_depth != "light":
        errors.append(
            f"{prefix}.requested_depth must be light for B rating"
        )


def validate_work_item(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if payload.get("schema_version") != WORK_ITEM_SCHEMA:
        errors.append(f"schema_version must equal {WORK_ITEM_SCHEMA!r}")
    for key in sorted(EXCLUDED_CONTROL_KEYS & payload.keys()):
        errors.append(f"top-level orchestration/write field is forbidden: {key}")
    _require_text(payload, "work_item_id", "work_item", errors)
    entity = _mapping(payload, "entity", errors)
    _validate_common_entity(entity, "entity", errors)
    workflow = _mapping(payload, "workflow_binding", errors)
    _validate_workflow_binding(workflow, "workflow_binding", errors)
    rating = _mapping(payload, "rating_context", errors)
    _validate_rating_context(rating, "rating_context", errors)
    requested_depth = _require_choice(
        payload, "requested_depth", REQUESTED_DEPTHS, "work_item", errors
    )
    _validate_rating_depth(rating, requested_depth, "work_item", errors)

    context = _mapping(payload, "research_context", errors)
    country = _require_text(context, "country_code", "research_context", errors)
    if country and not COUNTRY_CODE.fullmatch(country):
        errors.append("research_context.country_code must be two uppercase letters")
    _require_text(
        context, "search_language_mode", "research_context", errors
    )
    if not isinstance(context.get("bizseek_enabled"), bool):
        errors.append("research_context.bizseek_enabled must be boolean")
    for key in ("source_people", "company_clues", "baseline_routes"):
        _array(context, key, errors)

    if not _is_utc_rfc3339(payload.get("issued_at")):
        errors.append("issued_at must be an RFC3339 UTC timestamp")
    supplied_hash = payload.get("input_sha256")
    if not isinstance(supplied_hash, str) or not HEX_64.fullmatch(supplied_hash):
        errors.append("input_sha256 must be 64 lowercase hex characters")
    elif supplied_hash != computed_work_item_sha256(payload):
        errors.append("input_sha256 does not match canonical work-item content")
    return errors


def _validate_depth(
    depth: dict[str, Any],
    name: str,
    errors: list[str],
) -> tuple[str, str, bool]:
    prefix = f"depths.{name}"
    status = _require_choice(depth, "status", DEPTH_STATUSES, prefix, errors)
    outcome = _require_choice(
        depth, "route_outcome", DEPTH_OUTCOMES, prefix, errors
    )
    coverage = depth.get("coverage_complete")
    if not isinstance(coverage, bool):
        errors.append(f"{prefix}.coverage_complete must be boolean")
        coverage = False
    _require_text(depth, "notes", prefix, errors)
    if status and outcome and outcome not in OUTCOMES_BY_STATUS.get(status, set()):
        errors.append(
            f"{prefix}.route_outcome {outcome!r} is invalid for status {status!r}"
        )
    if status == "completed" and not coverage:
        errors.append(f"{prefix}.completed requires coverage_complete=true")
    return status, outcome, bool(coverage)


def _validate_people(
    people: list[Any],
    execution_status: str,
    requested_depth: str,
    errors: list[str],
) -> set[str]:
    person_refs: set[str] = set()
    for index, item in enumerate(people):
        prefix = f"people[{index}]"
        if not isinstance(item, dict):
            errors.append(f"{prefix} must be an object")
            continue
        person_ref = _require_text(item, "person_ref", prefix, errors)
        if person_ref in person_refs:
            errors.append(f"{prefix}.person_ref is duplicated")
        person_refs.add(person_ref)
        person_id = item.get("person_id")
        if person_id is not None and not _is_text(person_id):
            errors.append(f"{prefix}.person_id must be text or null")
        _require_text(item, "name", prefix, errors)
        _require_text(item, "title", prefix, errors)
        _require_text(item, "role_evidence", prefix, errors)
        backcheck = _require_choice(
            item,
            "person_backcheck_status",
            PERSON_BACKCHECK_STATUSES,
            prefix,
            errors,
        )
        linkedin = _require_choice(
            item,
            "linkedin_search_status",
            LINKEDIN_SEARCH_STATUSES,
            prefix,
            errors,
        )
        contact_status = _require_choice(
            item,
            "contact_research_status",
            CONTACT_RESEARCH_STATUSES,
            prefix,
            errors,
        )
        _require_text(item, "contact_research_notes", prefix, errors)
        if requested_depth == "light" and backcheck != "official_only_completed":
            errors.append(
                f"{prefix}.person_backcheck_status must be "
                "official_only_completed for light"
            )
        if requested_depth == "deep" and backcheck == "official_only_completed":
            errors.append(
                f"{prefix}.deep result requires full person backcheck"
            )
        if requested_depth == "light" and linkedin != "not_requested_light":
            errors.append(
                f"{prefix}.linkedin_search_status must be not_requested_light"
            )
        if requested_depth == "deep" and linkedin == "not_requested_light":
            errors.append(
                f"{prefix}.deep result requires a terminal LinkedIn search"
            )
        if execution_status == "completed" and (
            backcheck
            not in {
                "official_only_completed"
                if requested_depth == "light"
                else "completed"
            }
            or linkedin == "ambiguous_needs_review"
            or contact_status == "needs_manual_review"
        ):
            errors.append(
                f"{prefix} contains unresolved person checks in a completed result"
            )
    return person_refs


def _validate_routes(
    routes: list[Any], person_refs: set[str], errors: list[str]
) -> dict[str, int]:
    route_ids: set[str] = set()
    dedupe_keys: set[tuple[str, str, str, str]] = set()
    counts = {
        "person_light": 0,
        "company_light": 0,
        "person_all": 0,
        "company_all": 0,
    }
    for index, item in enumerate(routes):
        prefix = f"routes[{index}]"
        if not isinstance(item, dict):
            errors.append(f"{prefix} must be an object")
            continue
        route_id = _require_text(item, "route_id", prefix, errors)
        if route_id in route_ids:
            errors.append(f"{prefix}.route_id is duplicated")
        route_ids.add(route_id)
        scope = _require_choice(item, "scope", ROUTE_SCOPES, prefix, errors)
        route_type = _require_choice(
            item, "type", ROUTE_TYPES, prefix, errors
        )
        person_ref = item.get("person_ref")
        if scope == "person":
            if not _is_text(person_ref) or person_ref not in person_refs:
                errors.append(
                    f"{prefix}.person_ref must reference a retained person"
                )
        elif person_ref not in (None, ""):
            errors.append(f"{prefix}.company route must not have person_ref")
        if route_type == "linkedin_profile" and scope != "person":
            errors.append(f"{prefix}.linkedin_profile must have person scope")
        if route_type == "company_linkedin" and scope != "company":
            errors.append(f"{prefix}.company_linkedin must have company scope")
        _require_text(item, "raw_value", prefix, errors)
        normalized_value = _require_text(
            item, "normalized_value", prefix, errors
        )
        discovered_depth = _require_choice(
            item, "discovered_depth", REQUESTED_DEPTHS, prefix, errors
        )
        dedupe_key = (
            scope,
            str(person_ref or ""),
            route_type,
            normalized_value,
        )
        if dedupe_key in dedupe_keys:
            errors.append(
                f"{prefix} duplicates scope/person/type/normalized_value"
            )
        dedupe_keys.add(dedupe_key)
        verification = _require_choice(
            item,
            "verification",
            ROUTE_VERIFICATIONS,
            prefix,
            errors,
        )
        _require_choice(
            item, "confidence", CONFIDENCE_BANDS, prefix, errors
        )
        use_case = _require_choice(
            item, "use_case", ROUTE_USE_CASES, prefix, errors
        )
        _require_text(item, "source_family", prefix, errors)
        source_url = _require_text(item, "source_url", prefix, errors)
        if source_url and not _is_http_url(source_url):
            errors.append(f"{prefix}.source_url must be an http(s) URL")
        _require_text(item, "evidence_note", prefix, errors)
        if not _is_utc_rfc3339(item.get("observed_at")):
            errors.append(f"{prefix}.observed_at must be RFC3339 UTC")
        if verification != "public_confirmed" and use_case != "do_not_use":
            errors.append(
                f"{prefix} non-confirmed route must use use_case=do_not_use"
            )
        if route_type == "email":
            _require_choice(
                item, "email_risk", EMAIL_RISKS, prefix, errors
            )
            email_basis = _require_choice(
                item, "email_basis", EMAIL_BASES, prefix, errors
            )
            if email_basis == "pattern_only" and (
                verification == "public_confirmed" or use_case != "do_not_use"
            ):
                errors.append(
                    f"{prefix} pattern-only email cannot be confirmed or usable"
                )
        if verification == "public_confirmed":
            if scope == "person":
                counts["person_all"] += 1
                if discovered_depth == "light":
                    counts["person_light"] += 1
            elif scope == "company":
                counts["company_all"] += 1
                if discovered_depth == "light":
                    counts["company_light"] += 1
    return counts


def _validate_searched_families(
    items: list[Any],
    requested_depth: str,
    completed_light: bool,
    completed_deep: bool,
    errors: list[str],
) -> None:
    seen: set[str] = set()
    for index, item in enumerate(items):
        prefix = f"searched_families[{index}]"
        if not isinstance(item, dict):
            errors.append(f"{prefix} must be an object")
            continue
        family = _require_choice(
            item, "family", DEEP_SOURCE_FAMILIES, prefix, errors
        )
        if requested_depth == "light" and family not in LIGHT_SOURCE_FAMILIES:
            errors.append(
                f"{prefix}.family {family!r} is deep-only in a light result"
            )
        if family in seen:
            errors.append(f"{prefix}.family is duplicated")
        seen.add(family)
        _require_choice(
            item, "depth", REQUESTED_DEPTHS, prefix, errors
        )
        status = _require_choice(
            item,
            "status",
            SOURCE_FAMILY_STATUSES,
            prefix,
            errors,
        )
        query_or_url = item.get("query_or_url")
        evidence_url = item.get("evidence_url")
        reason = item.get("reason")
        if status == "found" and not _is_http_url(evidence_url):
            errors.append(f"{prefix}.found requires evidence_url")
        if status == "checked_no_route" and not _is_text(query_or_url):
            errors.append(f"{prefix}.checked_no_route requires query_or_url")
        if status in {"blocked", "not_applicable"} and not _is_text(reason):
            errors.append(f"{prefix}.{status} requires reason")
    if completed_light:
        missing = sorted(LIGHT_SOURCE_FAMILIES - seen)
        if missing:
            errors.append(f"completed light depth missing source families: {missing}")
    if requested_depth == "deep" and completed_deep:
        missing = sorted(DEEP_SOURCE_FAMILIES - seen)
        if missing:
            errors.append(f"completed deep depth missing source families: {missing}")


def validate_result(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    required = {
        "schema_version",
        "result_id",
        "run_id",
        "work_item_id",
        "supersedes_result_id",
        "entity",
        "workflow_binding",
        "rating_context",
        "requested_depth",
        "execution",
        "completion",
        "depths",
        "decision_maker_search",
        "people",
        "routes",
        "searched_families",
        "rejected_candidates",
        "baseline_comparison",
        "quality_gate",
        "summary",
        "source_skill_chain",
        "input_sha256",
        "result_sha256",
    }
    missing = sorted(required - payload.keys())
    if missing:
        errors.append(f"missing required top-level fields: {missing}")
    if payload.get("schema_version") != RESULT_SCHEMA:
        errors.append(f"schema_version must equal {RESULT_SCHEMA!r}")
    for key in sorted(EXCLUDED_CONTROL_KEYS & payload.keys()):
        errors.append(f"top-level orchestration/write field is forbidden: {key}")

    result_id = _require_text(payload, "result_id", "result", errors)
    _require_text(payload, "run_id", "result", errors)
    _require_text(payload, "work_item_id", "result", errors)
    supersedes = payload.get("supersedes_result_id")
    if supersedes is not None and not _is_text(supersedes):
        errors.append("supersedes_result_id must be text or null")

    entity = _mapping(payload, "entity", errors)
    _validate_common_entity(entity, "entity", errors)
    country = _require_text(entity, "country_code", "entity", errors)
    if country and not COUNTRY_CODE.fullmatch(country):
        errors.append("entity.country_code must be two uppercase letters")
    workflow = _mapping(payload, "workflow_binding", errors)
    _validate_workflow_binding(workflow, "workflow_binding", errors)
    rating = _mapping(payload, "rating_context", errors)
    _validate_rating_context(rating, "rating_context", errors)
    requested_depth = _require_choice(
        payload, "requested_depth", REQUESTED_DEPTHS, "result", errors
    )
    _validate_rating_depth(rating, requested_depth, "result", errors)

    execution = _mapping(payload, "execution", errors)
    _require_choice(
        execution,
        "skill",
        {"company-contact-list-finder-v2"},
        "execution",
        errors,
    )
    _require_text(execution, "skill_version", "execution", errors)
    execution_status = _require_choice(
        execution, "status", FINAL_STATUSES, "execution", errors
    )
    if not _is_utc_rfc3339(execution.get("started_at")):
        errors.append("execution.started_at must be RFC3339 UTC")
    if not _is_utc_rfc3339(execution.get("completed_at")):
        errors.append("execution.completed_at must be RFC3339 UTC")
    if _is_utc_rfc3339(execution.get("started_at")) and _is_utc_rfc3339(
        execution.get("completed_at")
    ):
        if _parse_rfc3339(execution["completed_at"]) < _parse_rfc3339(
            execution["started_at"]
        ):
            errors.append("execution.completed_at cannot precede started_at")

    completion = _mapping(payload, "completion", errors)
    light_completed = completion.get("light_completed")
    deep_completed = completion.get("deep_completed")
    if not isinstance(light_completed, bool):
        errors.append("completion.light_completed must be boolean")
        light_completed = False
    if not isinstance(deep_completed, bool):
        errors.append("completion.deep_completed must be boolean")
        deep_completed = False
    if deep_completed and not light_completed:
        errors.append("deep_completed=true requires light_completed=true")

    depths = _mapping(payload, "depths", errors)
    light = _mapping(depths, "light", errors)
    deep = _mapping(depths, "deep", errors)
    light_status, light_outcome, _ = _validate_depth(light, "light", errors)
    deep_status, deep_outcome, _ = _validate_depth(deep, "deep", errors)
    if light_completed != (light_status == "completed"):
        errors.append("light_completed must equal depths.light.status=completed")
    if deep_completed != (deep_status == "completed"):
        errors.append("deep_completed must equal depths.deep.status=completed")
    if requested_depth == "light" and deep_status != "not_requested":
        errors.append("light request requires depths.deep.status=not_requested")
    if requested_depth == "deep" and deep_status == "not_requested":
        errors.append("deep request requires a terminal deep status")
    if execution_status == "completed":
        if not light_completed:
            errors.append("completed execution requires completed light depth")
        if requested_depth == "deep" and not deep_completed:
            errors.append("completed deep execution requires deep_completed=true")

    people = _array(payload, "people", errors)
    person_refs = _validate_people(
        people, execution_status, requested_depth, errors
    )
    routes = _array(payload, "routes", errors)
    confirmed = _validate_routes(routes, person_refs, errors)
    if requested_depth == "light":
        for index, route in enumerate(routes):
            if (
                isinstance(route, dict)
                and route.get("discovered_depth") == "deep"
            ):
                errors.append(
                    f"routes[{index}].discovered_depth cannot be deep "
                    "in a light result"
                )
    confirmed_person = confirmed["person_all"]
    confirmed_company = confirmed["company_all"]

    decision = _mapping(payload, "decision_maker_search", errors)
    decision_level = _require_choice(
        decision, "level", DECISION_LEVELS, "decision_maker_search", errors
    )
    decision_status = _require_choice(
        decision,
        "status",
        DECISION_STATUSES,
        "decision_maker_search",
        errors,
    )
    _require_text(
        decision, "evidence_notes", "decision_maker_search", errors
    )
    _array(decision, "sources", errors)
    if people and decision_status not in {"named_person_found", "needs_review"}:
        errors.append(
            "retained people require decision_maker_search.status=named_person_found"
        )
    if not people and execution_status == "completed" and (
        decision_level != "enhanced"
        or decision_status != "no_named_person_after_enhanced_search"
    ):
        errors.append(
            "completed no-person result requires enhanced no-named-person search"
        )

    if light_outcome == "person_route_found" and confirmed["person_light"] == 0:
        errors.append("person_route_found requires a confirmed person route")
    if deep_outcome == "person_route_found" and confirmed_person == 0:
        errors.append("person_route_found requires a confirmed person route")
    for depth_name, outcome in (("light", light_outcome), ("deep", deep_outcome)):
        if outcome == "company_route_only":
            scoped_company = (
                confirmed["company_light"]
                if depth_name == "light"
                else confirmed_company
            )
            scoped_person = (
                confirmed["person_light"]
                if depth_name == "light"
                else confirmed_person
            )
            if scoped_company == 0 or scoped_person != 0:
                errors.append(
                    f"{depth_name} company_route_only requires company routes and no person route"
                )
            if decision_level != "enhanced":
                errors.append(
                    f"{depth_name} company_route_only requires enhanced decision-maker search"
                )
        if depth_name == "light":
            scoped_confirmed = (
                confirmed["person_light"] + confirmed["company_light"]
            )
        else:
            scoped_confirmed = confirmed_person + confirmed_company
        if outcome == "no_route_exhausted" and scoped_confirmed != 0:
            errors.append(
                f"{depth_name} no_route_exhausted cannot have confirmed routes"
            )

    searched = _array(payload, "searched_families", errors)
    _validate_searched_families(
        searched,
        requested_depth,
        bool(light_completed),
        bool(deep_completed),
        errors,
    )
    _array(payload, "rejected_candidates", errors)

    baseline = _mapping(payload, "baseline_comparison", errors)
    baseline_source = _require_choice(
        baseline,
        "baseline_source",
        {"none", "work_item"},
        "baseline_comparison",
        errors,
    )
    for key in (
        "baseline_verified_person_route_count",
        "current_verified_person_route_count",
        "private_route_delta",
    ):
        value = baseline.get(key)
        if not isinstance(value, int) or isinstance(value, bool):
            errors.append(f"baseline_comparison.{key} must be an integer")
    layer1 = _require_choice(
        baseline,
        "layer1_result",
        {"pass", "no_improvement"},
        "baseline_comparison",
        errors,
    )
    if baseline_source == "none" and baseline.get(
        "baseline_verified_person_route_count"
    ) not in (0, None):
        errors.append("baseline_source=none requires baseline count 0")
    if baseline.get("current_verified_person_route_count") != confirmed_person:
        errors.append(
            "baseline current person-route count must match confirmed person routes"
        )
    if layer1 == "pass" and baseline.get("private_route_delta", 0) <= 0:
        errors.append("baseline layer1 pass requires positive private-route delta")

    quality = _mapping(payload, "quality_gate", errors)
    quality_result = _require_choice(
        quality, "result", QUALITY_RESULTS, "quality_gate", errors
    )
    pass_basis = quality.get("pass_basis")
    if quality_result == "pass":
        if pass_basis not in QUALITY_PASS_BASES:
            errors.append(
                f"quality_gate.pass_basis must be one of {sorted(QUALITY_PASS_BASES)}"
            )
    elif pass_basis not in (None, ""):
        errors.append("non-pass quality result must not have pass_basis")
    if not isinstance(quality.get("strict_research_audit_complete"), bool):
        errors.append(
            "quality_gate.strict_research_audit_complete must be boolean"
        )
    _array(quality, "issues", errors)
    if not _is_utc_rfc3339(quality.get("checked_at")):
        errors.append("quality_gate.checked_at must be RFC3339 UTC")

    status_quality = {
        "completed": "pass",
        "review": "review",
        "failed": "fail",
    }
    if execution_status and quality_result != status_quality.get(execution_status):
        errors.append("execution.status and quality_gate.result do not match")
    if pass_basis == "verified_person_route_improved" and layer1 != "pass":
        errors.append(
            "verified_person_route_improved requires baseline layer1 pass"
        )
    if pass_basis == "strict_research_exhausted":
        if requested_depth != "deep" or not quality.get(
            "strict_research_audit_complete"
        ):
            errors.append(
                "strict_research_exhausted requires deep and a complete strict audit"
            )
    if pass_basis == "light_official_research_complete" and (
        requested_depth != "light" or not light_completed
    ):
        errors.append(
            "light_official_research_complete requires a completed light request"
        )

    summary = payload.get("summary")
    if not isinstance(summary, dict):
        errors.append("summary must be an object")
    else:
        expected_summary = {
            "verified_person_route_count": confirmed_person,
            "verified_company_route_count": confirmed_company,
            "inferred_candidate_count": len(
                payload.get("rejected_candidates", [])
            )
            + sum(
                1
                for route in routes
                if isinstance(route, dict)
                and route.get("verification") != "public_confirmed"
            ),
        }
        for key, expected in expected_summary.items():
            if summary.get(key) != expected:
                errors.append(
                    f"summary.{key} must equal computed value {expected}"
                )
    skill_chain = _array(payload, "source_skill_chain", errors)
    if not all(_is_text(item) for item in skill_chain):
        errors.append("source_skill_chain entries must be non-empty text")
    elif not skill_chain or skill_chain[0] != "company-contact-list-finder-v2":
        errors.append(
            "source_skill_chain must start with company-contact-list-finder-v2"
        )

    input_hash = payload.get("input_sha256")
    if not isinstance(input_hash, str) or not HEX_64.fullmatch(input_hash):
        errors.append("input_sha256 must be 64 lowercase hex characters")
    result_hash = payload.get("result_sha256")
    if not isinstance(result_hash, str) or not HEX_64.fullmatch(result_hash):
        errors.append("result_sha256 must be 64 lowercase hex characters")
    else:
        computed = computed_result_sha256(payload)
        if result_hash != computed:
            errors.append("result_sha256 does not match canonical result content")
        expected_id = "cmres_" + computed[:24]
        if result_id and result_id != expected_id:
            errors.append(f"result_id must equal {expected_id}")
    return errors
