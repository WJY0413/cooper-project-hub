---
name: company-contact-list-finder-v2
description: Research exactly one already-assigned B-or-above company for the user's LinkedIn contact-mining stage and return one validated, evidence-backed canonical result without writing any database, JSONL, Excel, queue, or workflow state. Use for light official-site contact research or deep key-person/public-route research after a professional packaging skill has supplied a single company work item. Preserve the established company-contact-list-finder research depth while excluding queue selection, batch splitting, visible-thread control, callbacks, writeback, outreach, and master admission.
---

# Company Contact List Finder V2

Research one supplied company and return one terminal
`contact-mining-result/v1` object. Preserve the old mining effect; change only
the interface and ownership boundaries.

Read:

- `references/work-item-contract.md` before accepting an assignment.
- `references/result-contract.md` before constructing the result.
- `references/research-gate.md` before light/deep research or QA.

Validate machine-readable input and output with:

```powershell
python <skill-dir>\scripts\validate_contact_mining_contract.py work-item <work-item.json>
python <skill-dir>\scripts\validate_contact_mining_contract.py result <result.json>
```

## Hard boundary

Accept one work item containing one stable company ID. Produce one result and
stop.

Never:

- select, enumerate, sort, split, or release a queue;
- create or manage visible tasks, workers, callbacks, continuation messages, or
  controller state;
- start a second company;
- write SQLite, BDdb, JSON, JSONL, CSV, Excel, checkpoints, or workflow tags;
- invoke the database-writing path of `$official-contact-research`;
- rerate the company, decide admission, generate outreach, or contact anyone;
- return `next_company`, `NEXT_COMPANY_READY`, release tokens, or workbook
  writeback fields.

Treat `rating_context` and `workflow_binding` as immutable upstream facts.
Reject a free-text company name or domain used in place of the resolver-issued
company ID.

If a request contains more than one company or asks for queue design, package
splitting, visible tasks, release, self-message, or callback behavior, do not
propose a split, worker count, launch plan, or confirmation-to-launch promise.
Route the unchanged multi-company/control request to the designated
professional packaging skill and do not start V2.

## Depth selection

For future LinkedIn Stage 7（联系人挖掘）, depth is determined by the immutable
upstream final rating, not by worker preference:

- `A+`, `A`, `A-`, `B+`: use the **deep** priority-company lane.
- `B`: use the **light** official-contact lane only.

The work-item validator rejects a mismatched rating/depth pair. A result may
not silently upgrade or downgrade that lane.

### Light

Run a research-only official-site lane:

- verify the official company identity and domain;
- check the homepage/footer, Contact, About, Team/People, Locations, Sales,
  Service, Parts, and other applicable official pages;
- search person-bearing pages before accepting a generic route;
- separate named-person, department, generic, phone, branch, WhatsApp,
  and company-social routes;
- discard website contact forms: do not retain, score, report, or use them as
  fallback contact routes or contact evidence;
- retain every checked official family and no-route/blocked reason.

Use the current `$official-contact-research` research order only as a source
rule. Do not invoke its database workflow.

### Deep

Complete light first, then preserve the established full chain:

`company anchor -> registry/legal -> key people -> person backcheck ->
third-party/public route mining -> personal LinkedIn -> exhaustion -> QA`

Use `$public-contact-mining-deep` as the deep source-family and exhaustion
baseline. Use `$company-key-people-mapper`,
`$company-person-background-check`, and `$linkedin-profile-link-finder` only
in return-only mode. Do not inherit their queue, rating, Excel, greeting,
outreach, or writeback behavior.

## Required workflow

1. Validate the work item and its input hash.
2. Verify `entity_type=company`, stable `entity_id`,
   `workflow_binding.stage=contact_mining`, current tag/revision, rating B or
   above, and explicit contact-mining authorization.
3. Confirm company identity, official domain, country, same-name risk, legal
   entity, and parent/acquisition risk.
4. Select the local search language from the supplied context. Never replace
   a supplied table-level BizSeek decision with a per-company guess.
5. Run the requested depth. A deep request includes a complete light lane.
6. Map owner/founder/MD/director before sales/channel/product/service roles.
7. When no named decision maker is found, run and record enhanced
   decision-maker discovery before accepting company-route-only output.
8. In light, keep retained-person checks to official-site role and route
   evidence. In deep, additionally check each retained person independently
   for current personal LinkedIn and fallback public source families.
9. Continue beyond the first generic route until each required source family
   and person lane is terminal: `found`, `checked_no_route`, `blocked`, or
   `not_applicable`.
10. Separate public-confirmed routes from inferred, ambiguous, stale, and
    rejected candidates. Never promote a guessed email.
11. Build one canonical result, compute its stable hash/ID, and run the
    contract validator plus the two-layer quality gate.
12. If QA fails, perform at most one focused repair for this same company.
    Return `review` or `failed` if it still does not pass. Never disguise an
    exception as completion.
13. Return the validated result to the caller or
    `$contact-mining-result-writer`; do not persist it.

## Completion semantics

- `completed` means the required search and QA completed. It does not mean a
  route was found.
- `deep_completed=true` requires `light_completed=true`.
- Use `person_route_found` only when at least one named-person route is
  `public_confirmed`.
- Use `company_route_only` only after enhanced decision-maker search found no
  usable person route.
- Use `no_route_exhausted` only when required source families are terminal and
  the strict audit passes.
- Use `review` for unresolved identity, role, evidence, or material access
  ambiguity.
- Use `failed` for incomplete work caused by a technical failure.

## Quality gate

Keep the old two-layer intent without the old queue/checkpoint schema:

1. Pass on a verified named-person route improvement.
2. When there is no improvement, pass only after the applicable research depth
   is audibly exhausted.

- A light result may use
  `quality_gate.pass_basis=light_official_research_complete`.
- A deep result with a person-route improvement uses
  `verified_person_route_improved`.
- A deep result without improvement uses `strict_research_exhausted`.
- Company routes never count as named-person route improvement.
- Inferred, ambiguous, stale, pattern-only, or rejected routes never count as
  usable output.

## Final response

Return the canonical result plus a compact Chinese status line. Keep names,
titles, URLs, emails, phones, JSON keys, schema values, and evidence strings
verbatim. Do not include a next-company instruction or writeback claim.
