---
name: official-company-shortlist-rating
description: Use as the user's lightweight company-level shortlist controller before contact research. Trigger for dealer, distributor, partner, exhibitor, booth-neighbor, prospect-table, turf, groundcare, garden machinery, agricultural machinery, robotic mower, line-marking robot, or regional channel screening. It classifies companies from official/public website evidence, creates a compact company shortlist, routes targets to the right next workflow, and leaves contact extraction to official-contact-research or other specialist skills. When live web search is needed, first apply web-research-token-efficient mode selection and output compression.
metadata:
  short-description: Company shortlist controller for BD screening
---

# Official Company Shortlist Rating

Use this as the company-level gate before deeper BD work. Keep it lean: decide whether each company deserves more work and route it to the right next workflow. Do not build contact databases here.

## Operating Mode

If web verification is needed, first apply `web-research-token-efficient`:
- `LIGHT` for broad lists, exhibitor maps, booth-neighbor scans, and first-pass screening.
- `DEEP` only for selected companies when the user asks for stronger evidence.

Default batch size: 15 companies. For a small exhibitor cluster, process the full visible set if quality remains stable.

## Input

Accept CSV/XLSX, pasted tables, company lists, exhibitor maps, booth-neighbor lists, or rough company-name sets.

Minimum useful fields: company name. Preserve any available booth, website, phone, source row, country/region, and user notes.

## Evidence Standard

Prefer official websites and company-controlled pages. Use high-signal industry pages only when official evidence is missing or to confirm dealer/partner relationships.

For each company, capture only compact evidence:
- business type
- relevant products/services
- customer overlap
- dealer/distributor/agent/partner signal if present
- unresolved gap when evidence is weak

Missing website or sparse evidence is `skip_backfill` or `review_later`, not automatic `exclude`.

## Output

One company equals one row. Keep columns compact.

Recommended columns:
1. `Company`
2. `Official website`
3. `Phone`
4. `Rating`
5. `Company type`
6. `Compact company profile`
7. `Shortlist status`
8. `Confidence`
9. `Evidence / route note`
10. `Source URL`

Use Chinese headers when the user asks for Chinese output.

## Rating Guide

Use ratings only as routing signals, not long justification.

- `A`: direct high-fit dealer/distributor/channel or strong service network.
- `A-`: high-fit but smaller, more specialized, or needs one key verification.
- `B+`: useful route-specific target, such as dealer-network seed, pilot resource, or adjacent channel.
- `B`: possible value but not first wave.
- `C`: exclude only with explicit low-relevance evidence.

## Shortlist Status

Use these statuses to avoid forcing every useful target into contact research:

- `contact_research_next`: company itself is worth contact-route research.
- `dealer_network_mining_next`: company is a brand/manufacturer/network seed; mine its dealers or agents.
- `pilot_or_ecosystem_next`: institution, demo, trial, association, or ecosystem resource worth non-distributor follow-up.
- `review_later`: possible value, not first wave.
- `skip_backfill`: official website/domain match is missing, ambiguous, or unreliable.
- `exclude`: low relevance with concrete reason.

## Handoff

After the user accepts the shortlist:
- Send `contact_research_next` to `official-contact-research`.
- Send named decision-maker needs to `company-key-people-mapper` or `company-person-background-check`.
- Send public business route deep dives to `public-business-contact-mining`.
- Send distributor/dealer landscape work to `groundcare-distributor-background` or a dedicated dealer-mining workflow.
- Keep `dealer_network_mining_next` and `pilot_or_ecosystem_next` in separate queues.

## QA Gate

Before finalizing a batch, check:
- one company per row
- no forced ratings from weak evidence
- no contact database fields or multi-email extraction
- `C/exclude` has concrete evidence
- last rows are as specific as first rows
- output is compact enough for Excel or follow-on research

Stop and report if evidence is too weak, websites are ambiguous, or profiles become generic.

## Resume Note

For multi-batch work, record: source file/list, processed range, output file, count by rating/status, skip count, QA result, and next exact range.

## Startup Intent Line

我将先用官网公开信息筛选公司级BD价值，给出评级、证据和是否进入联系人研究的建议。

