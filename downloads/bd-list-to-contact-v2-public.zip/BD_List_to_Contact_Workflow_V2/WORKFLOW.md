# BD List-to-Contact Workflow V2

## Purpose

Turn a regional or industry search brief into a verified, sales-ready contact-intelligence result. This package contains the three skills that form the current workflow. It does not send outreach or alter customer-facing systems.

## Workflow

1. **Find target companies — `lead-discovery-agent`**
   - Build a source-backed universe of distributors, dealers, resellers, service partners, or other channel targets.
   - Deduplicate candidates and retain source evidence, region, channel role, and fit rationale.

2. **Screen the list — `official-company-shortlist-rating`**
   - Use official/public evidence to assess company fit and decide which companies warrant contact research.
   - Separate first-wave contact targets from dealer-network seeds, ecosystem leads, review-later items, and exclusions.

3. **Research key contacts — `company-contact-list-finder-v2`**
   - For each approved company, verify company identity, map decision makers, and identify publicly confirmed business contact routes.
   - Use the light official-site lane for `B` companies and the deep lane for `B+`, `A-`, `A`, and `A+` companies.
   - Return one validated `contact-mining-result/v1` per company; do not guess email addresses or treat website forms as usable contact routes.

## Handoffs and controls

- The company list and rating are upstream facts. Contact research must use a stable company ID, explicit authorization, country/language context, and the rating-selected depth.
- Each contact result retains the role evidence, source URLs, route verification state, rejected candidates, research coverage, and quality conclusion.
- Only publicly confirmed person or company routes can be used for first outreach. Inferred, ambiguous, stale, or rejected routes are marked `do_not_use`.
- Database or Excel writeback, queue release, and outbound communication are intentionally outside this package and require their own approval-controlled workflows.

## Package contents

- `skills/lead-discovery-agent/`
- `skills/official-company-shortlist-rating/`
- `skills/company-contact-list-finder-v2/`

## Installation

Copy the three folders under `skills/` into the target Codex skills directory. Keep each folder name unchanged so its trigger metadata and bundled references remain valid.
