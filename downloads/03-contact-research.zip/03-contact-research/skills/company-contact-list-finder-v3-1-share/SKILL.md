---
name: company-contact-list-finder-v3-1-share
description: Research public business contacts and company context for requested V3.1 contact-research work. Find relevant people and exact public contact routes, write a sourced company introduction, and preserve source text for reusable business facts.
---

# Company Contact Research V3.1

Deliver useful contacts and a supported understanding of the requested company: who matters, how they can be reached, what the company does, and which published facts can support later outreach.

## Establish the task

Start from the supplied company name, website, company list or existing assignment. Resolve the official identity before attributing contacts. Ask only if ambiguity would change which company is researched. Use relevant supplied research and expand the gaps; recheck facts whose age or conflicting evidence matters.

Follow the user's requested scope, depth, budget and output format. A company name or website is enough to start ordinary research. When working inside an assigned workflow, use its company identity and workspace without selecting another queue item. Do not invent a rating-to-depth rule or require a particular model, scheduler or task file for standalone work.

## Research people and routes

Use the business purpose to prioritize people. For channel development, look for owners, founders, managing directors and relevant sales, distribution, service or product leaders. Favor responsibility relevant to the request over collecting a large staff list.

- Establish the official website and its contact/team/about pages; use available clues to target further searches.
- For each useful person, research company association, current role, published personal business contact routes and the exact personal LinkedIn profile where discoverable. Use the person's name, company/domain, role and relevant local-language terms to follow concrete leads through company pages, announcements, partner pages, events and public professional profiles. Finding a name or a general company mailbox is not a reason to stop while useful personal-route leads remain.
- Separate personal email/phone/WhatsApp, personal LinkedIn, department routes and general company routes. A company mailbox remains useful without becoming a personal route.
- Use relevant official announcements, partner or brand pages, trade associations, event pages and credible secondary sources to resolve gaps. Keep source and date context with the finding; explain historical or conflicting evidence when it affects use.
- If no useful person is found, make a focused additional search using company/domain, leadership or relevant role terms and available industry clues. Return the company routes and actual search limitations if no person is found.

Copy contact details exactly as published; do not invent addresses from email patterns or present unsupported employment, route ownership or purchasing authority as established facts. Retain useful evidence-backed leads under normal research uncertainty. Do not repeatedly label them "possible" or "pending confirmation", or require certainty before including them. Briefly explain a conflict, attribution gap or usage restriction only when it materially changes how the contact can be used; place the note once beside the affected finding. This adds no approval, verification pass or completion gate.

## Add company context

Write a concise neutral company introduction covering the evidenced business, relevant products or brands, customers/sectors and geographic coverage. Include projects, news or events when they explain the company or provide a useful conversation opening. Choose detail by relevance and evidence, without a fixed fact quota.

Link important statements to the source wording that supports them. Keep business inferences separate from published facts. An old project remains historical. Offer factual outreach hooks with their source and date; draft an email only when requested.

Preserve acquired source text and relevant public documents with their URLs, acquisition times and quote locations using [evidence-contract.md](references/evidence-contract.md). Record unavailable or partial content honestly.

## Decide when research is sufficient

Follow concrete leads that can improve access to a relevant person or materially clarify the company context. Choose depth by the value of the lead and the user's scope/budget, without fixed search counts. Avoid repeated equivalent searches and whole-site collection.

Finish when the requested coverage has been addressed and further reasonable research is unlikely to change the useful result. A documented inaccessible source, inconclusive role check or absence of a published personal email can be a valid final outcome. State any work not performed or still materially unresolved; do not describe it as checked.

Keep research coverage, available contacts and company suitability distinct. Normal uncertainty or a missing optional field does not invalidate useful contacts. For a requested list, continue the other companies within the authorized scope when one company's sources are limited.

## Deliver

Use the requested format. Otherwise provide:

1. Company identity, official website and a sourced company introduction.
2. Relevant people with role, source and the personal routes or LinkedIn profiles found.
3. Exact contact routes with type, owner/scope and source; include usage limitations where material.
4. Useful business facts or outreach hooks linked to supporting excerpts.
5. Saved source references and any remaining gaps that affect practical use, without repeating notes already attached to a finding.

Simple source labels or links are sufficient for a standalone report. Backend IDs, hashes, receipts and generated metadata are not research tasks.

This portable edition delivers standalone research reports and evidence files. Legacy receiver/MCP adapters and pilot records are not bundled. Connecting a private receiver is a separate integration task; do not claim submission or production acceptance from a standalone report.
