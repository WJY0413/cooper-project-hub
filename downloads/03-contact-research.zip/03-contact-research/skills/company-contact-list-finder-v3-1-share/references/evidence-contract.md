# Reusable source evidence

Keep enough source material to recover and check a fact later without relying on the summary alone.

## Capture

For each source used, retain its exact URL, the actual acquisition time supplied or recorded during collection, the acquired original text or relevant public document, and any access limitation. Keep publication/event dates separate from acquisition time. If the time or content is unavailable, say so instead of reconstructing it.

Save relevant original text, its URL and acquisition time as sources are collected, rather than reconstructing them when writing the final report. Use the task's output location when file writing is available. Preserve the returned wording; put summaries and annotations separately. Retain an original public document when it was actually acquired, is relevant and may be saved. Follow applicable source and quotation limits.

Label the representation accurately: page text, partial returned text, search snippet, excerpt or document. A tool's complete response need not be the complete webpage. Do not describe a URL-only citation, snippet or summary as an archived page. If saving is unavailable, provide permitted supporting excerpts and URLs in the report and identify the missing archive.

Use meaningful source filenames or simple source labels. Record the paths actually written. The research model does not generate, fill or verify hash/digest fields; backend integrity metadata belongs to the tools that require it.

## Link facts

Connect each important claim to its supporting source and exact excerpt. Preserve enough local context to retain the relationship between a name, role, company and contact route; isolated words that lose that relationship are not useful evidence. Use a heading, paragraph, page number or existing line reference to locate it; calculated character offsets and machine IDs are unnecessary unless the actual input contract supplies them.

Keep the company introduction and outreach facts traceable to this evidence. For an inference, state the reasoning and supporting published facts. Snippets may provide leads or clearly qualified findings, but should not be presented as verified full-page support.

## Reuse

Reuse saved sources for stable context and new facts supported by the saved wording. Check changing roles, routes and time-sensitive claims when currentness matters. Reuse does not refresh the original collection date. Preserve an earlier source version when a material change needs explanation.

Archive only task-relevant public content. Exclude credentials, cookies and unrelated personal information. Record any redaction or transformation separately from the original representation.
