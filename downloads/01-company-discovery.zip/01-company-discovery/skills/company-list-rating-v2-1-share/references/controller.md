# Controller operation

Requirements: Python 3.10+ and jsonschema (check availability on the recipient machine). Install nothing automatically when missing. This helper makes no model, web, MCP or production API calls.

## Input and commands

Use a new sidecar SQLite ledger. The helper refuses any existing database that lacks its V2.1 marker; never point it at the V2 or production libraries.

Prepare a JSON object with run_id, policy and companies. policy requires mode (rating or qualification_only), target_definition and exclusions (list of explicit rules). Each company requires company_id, company_name, official_website (URL or null), country_or_region (text or null), source_mappings (nonempty array), and restrictions (array). Preserve existing source IDs and restrictions. Do not generate company IDs from free-text names.

```powershell
python -X utf8 scripts/rating_v21.py prepare --db <new-sidecar.sqlite> --input <batch.json>
python -X utf8 scripts/rating_v21.py next --db <sidecar.sqlite> --run-id <run>
python -X utf8 scripts/rating_v21.py submit --db <sidecar.sqlite> --run-id <run> --company-id <id> --research <form.json>
python -X utf8 scripts/rating_v21.py readback --db <sidecar.sqlite> --run-id <run> --company-id <id>
python -X utf8 scripts/rating_v21.py status --db <sidecar.sqlite> --run-id <run>
```

next is a read-only resume pointer, not a concurrent queue claim. Default is one controller and one execution lane. It skips saved submissions, including pending research. Do not run multiple consumers against next as though it allocates exclusive work. Additional companies per turn or parallel lanes need explicit controller allocation; this skill does not start them.

Write the next task material to the assigned task file if required, and supply a form path and exact submission command. The model only fills assets/research.schema.json. The caller can also invoke receive(db, run_id, company_id, research) directly from a future typed tool. No new globally registered MCP server is required for local use.

## Storage and acceptance

One transaction stores the company result and canonical form. Equivalent repeat submissions return the original receipt; different repeated content is rejected. A crashed transaction either saves the whole result or none of it. The saved record preserves the assignment, source mappings, restrictions, research facts, company-route quality and received_at. SQLite is the authority; form JSON is transport only.

readback independently loads the persisted record, revalidates its form against the assignment and checks the receiver-derived receipt. accepted_structure=true means that check passed. independent_acceptance=pending and production_accepted=false remain explicit. It does not verify source content, real tool events, public contact ownership or business correctness.

Controller evidence review must confirm:
- exact company/domain attribution, including evidenced parent/brand relationships;
- cited pages were actually read in this task or supplied as dated reusable evidence;
- claims, roles and contact values occur on the cited official pages;
- direct negative proof for C/no_go and a specific next check for unresolved decisions;
- personal routes were not disguised as generic routes; route quality matches its purpose.

Keep original query/open events externally. Do not ask workers to manufacture telemetry. Reject false evidence rather than repeatedly asking the model to make a schema pass.

A recorded unavailable site or missing public route can be a completed check. Missing an assigned check is partial work. Route availability never upgrades/downgrades the business rating. Status metrics derive from saved results; no auto-research on pending_research.

## Compatibility and delivery

This new ledger is not a schema-version-5 V2 ledger and not a production admission database. Do not pass it to the old V2 validator or LinkedIn writer. Existing V2/Stage-6 runs remain on V2 until a separate versioned adapter is implemented and verified. Upstream contact seeds can be supplied as source clues, but must be checked on the current official page before retention; do not assert legacy seed-hash provenance from this form.

When an export is requested, create a separate table with company, website, region, role, profile, rating, rating reason and evidence URLs, retaining full evidence and routes separately. Spreadsheet generation requires suitable local tooling such as openpyxl; it is not provided by this receiver. Missing grades stay visibly pending; never export pending as C. Existing line-marker dual-library intake and external-communication authorization rules still apply. No external delivery occurs through this helper.
