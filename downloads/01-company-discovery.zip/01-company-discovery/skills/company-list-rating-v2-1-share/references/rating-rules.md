# Rating rules

Apply the target policy supplied by the controller. Do not infer the intended product, geography or end-user treatment from a person's title or the skill name. If material scope is absent, the controller resolves it before dispatch.

| Rating | Evidence-based distinction |
| --- | --- |
| A+ | Direct fit with unusually strong demonstrated distribution, delivery/service capacity or strategic reach. |
| A | Strong direct fit with demonstrated channel/execution capability and a concrete cooperation path. |
| A- | Strong relevant specialist with a credible cooperation path; a non-critical capability detail limits a stronger conclusion. |
| B+ | Relevant business with demonstrated cooperation value, sufficient to justify next-stage work. |
| B | Confirmed adjacent or secondary opportunity; explain the specific limitation. |
| C | Direct evidence meets an explicit exclusion in the supplied target policy. |
| pending_research | A required identity, business or role fact is unresolved; state the missing proof and narrow next check. |

Do not automatically lower a company for small size, sparse web design or no email. Scale may establish A+ but lack of scale data does not erase direct-fit evidence. Distinguish actual distribution or service execution from selling paint, listing customers, sponsoring sport or generic landscaping.

For any letter rating, retain identity and business evidence. For A+ through B+, separately support relevance and cooperation capability; these may be distinct facts on the same page. A+ additionally needs demonstrated capacity/reach evidence. C requires direct exclusion evidence, not failed retrieval. Record concise facts with exact opened source URLs. Public corroboration can resolve identity but does not replace official business evidence for a high-priority claim.

The controller may explicitly choose qualification_only when a project forbids ranking. Then rating is null and qualification is target, verify_later or no_go; apply the same evidence standards. For normal rating mode, C maps to no_go, pending_research to verify_later, and other ratings to target.

Roles are multi-select dealer, contractor, terminal, other; retain only evidenced roles. Terminal sites can be retained when the project allows them. Existing-customer and blacklist flags remain separate controller restrictions, not an invented commercial grade. Duplicate source records map to a company; duplication is not a business-quality fact.

For line marking, distinguish sports-turf water-based marking from parking/industrial high-pressure marking. Do not infer surface/coating compatibility. Follow the current project policy on target/verify-later/no-go and retained terminal sites.
