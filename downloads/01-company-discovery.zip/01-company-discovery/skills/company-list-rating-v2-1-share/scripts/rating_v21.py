"""Local V2.1 rating form receiver. No network, model calls or production writes."""
from __future__ import annotations
import argparse
import json
import re
import sqlite3
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit
from jsonschema import Draft202012Validator

KIND = "company-list-rating-v2-1/1"
SCHEMA = json.loads((Path(__file__).resolve().parents[1] / "assets/research.schema.json").read_text(encoding="utf-8"))
VALIDATOR = Draft202012Validator(SCHEMA)

def packed(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def require(condition, message):
    if not condition:
        raise ValueError(message)

def text(value):
    return isinstance(value, str) and bool(value.strip())

def host(url):
    p = urlsplit(url or "")
    require(p.scheme == "https" and p.hostname and not p.username and not p.password, "Expected an official HTTPS URL")
    return p.hostname.lower().removeprefix("www.").rstrip(".")

def on_site(url, site):
    a, b = host(url), host(site)
    return a == b or a.endswith("." + b)

def open_db(path, create=False):
    path = Path(path).resolve()
    if path.exists():
        with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as probe:
            try:
                marker = probe.execute("SELECT value FROM v21_meta WHERE key='kind'").fetchone()
            except sqlite3.Error as exc:
                raise ValueError("Refusing non-V2.1 database") from exc
            require(marker is not None and marker[0] == KIND, "Refusing unknown ledger version")
    else:
        require(create, "Ledger does not exist; controller must prepare it")
        path.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(path, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    if create:
        with c:
            c.execute("CREATE TABLE IF NOT EXISTS v21_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
            c.execute("INSERT OR IGNORE INTO v21_meta VALUES('kind',?)", (KIND,))
            c.execute("CREATE TABLE IF NOT EXISTS runs(run_id TEXT PRIMARY KEY,policy TEXT NOT NULL)")
            c.execute("CREATE TABLE IF NOT EXISTS assignments(run_id TEXT,company_id TEXT,position INTEGER NOT NULL,task TEXT NOT NULL,PRIMARY KEY(run_id,company_id),FOREIGN KEY(run_id) REFERENCES runs(run_id))")
            c.execute("CREATE TABLE IF NOT EXISTS results(result_id INTEGER PRIMARY KEY,run_id TEXT,company_id TEXT,research TEXT NOT NULL,received_at TEXT NOT NULL,receipt TEXT NOT NULL,UNIQUE(run_id,company_id),FOREIGN KEY(run_id,company_id) REFERENCES assignments(run_id,company_id))")
    return c

def check_batch(batch):
    require(isinstance(batch, dict) and set(batch) == {"run_id", "policy", "companies"}, "Batch requires run_id, policy, companies only")
    require(text(batch["run_id"]), "run_id is required")
    p = batch["policy"]
    require(isinstance(p, dict) and set(p) == {"mode", "target_definition", "exclusions"}, "Policy requires mode, target_definition, exclusions")
    require(p["mode"] in {"rating", "qualification_only"} and text(p["target_definition"]), "Explicit target policy is required")
    require(isinstance(p["exclusions"], list) and all(text(x) for x in p["exclusions"]), "Exclusions must be a list of explicit rules")
    require(isinstance(batch["companies"], list) and batch["companies"], "At least one company is required")
    seen = set()
    for t in batch["companies"]:
        require(isinstance(t, dict) and set(t) == {"company_id", "company_name", "official_website", "country_or_region", "source_mappings", "restrictions"}, "Unexpected assignment fields")
        require(text(t["company_id"]) and text(t["company_name"]), "Stable company ID and name are required")
        require(t["company_id"] not in seen, "Duplicate company ID")
        seen.add(t["company_id"])
        if t["official_website"] is not None:
            host(t["official_website"])
        require(t["country_or_region"] is None or text(t["country_or_region"]), "Invalid country/region")
        require(isinstance(t["source_mappings"], list) and t["source_mappings"] and all(isinstance(x, dict) and x for x in t["source_mappings"]), "Preserve nonempty source mappings")
        require(isinstance(t["restrictions"], list) and all(text(x) for x in t["restrictions"]), "Restrictions must be strings")

def prepare(path, batch):
    check_batch(batch)
    with closing(open_db(path, create=True)) as c, c:
        old = c.execute("SELECT policy FROM runs WHERE run_id=?", (batch["run_id"],)).fetchone()
        if old:
            tasks = [json.loads(r["task"]) for r in c.execute("SELECT task FROM assignments WHERE run_id=? ORDER BY position", (batch["run_id"],))]
            require(old["policy"] == packed(batch["policy"]) and tasks == batch["companies"], "Existing run is immutable; use a new run ID")
            return {"run_id": batch["run_id"], "prepared": len(tasks), "replayed": True}
        c.execute("INSERT INTO runs VALUES(?,?)", (batch["run_id"], packed(batch["policy"])))
        for i, task in enumerate(batch["companies"]):
            c.execute("INSERT INTO assignments VALUES(?,?,?,?)", (batch["run_id"], task["company_id"], i, packed(task)))
    return {"run_id": batch["run_id"], "prepared": len(batch["companies"]), "replayed": False}

def assignment(c, run_id, company_id):
    row = c.execute("SELECT a.task,r.policy FROM assignments a JOIN runs r USING(run_id) WHERE a.run_id=? AND a.company_id=?", (run_id, company_id)).fetchone()
    require(row is not None, "Company is not assigned to this run")
    return json.loads(row["task"]), json.loads(row["policy"])

def validate(research, task, policy):
    errors = sorted(VALIDATOR.iter_errors(research), key=lambda e: str(list(e.path)))
    require(not errors, "schema: " + "; ".join(str(list(e.path)) + ": " + e.message for e in errors[:4]))
    identity, a, contacts = research["identity"], research["assessment"], research["contacts"]
    require(identity["company_name"] == task["company_name"], "Company name differs from assignment; record legal/trading variants in evidence")
    require(text(a["reason"]), "Rating reason is required")
    evidence = research["evidence"]
    for e in evidence:
        require(text(e["fact"]), "Evidence fact is empty")
        host(e["source_url"])
    official = [e for e in evidence if e["source_kind"] == "official"]
    if identity["status"] == "confirmed":
        require(identity["official_website"] is not None, "Confirmed identity needs official website")
        host(identity["official_website"])
        if task["official_website"] is not None:
            require(host(identity["official_website"]) == host(task["official_website"]), "Official domain differs from assignment; controller must verify redirects or identity changes")
        require(any(e["claim_type"] == "identity" and on_site(e["source_url"], identity["official_website"]) for e in official), "Confirmed identity needs matching official evidence")
        for e in official:
            require(on_site(e["source_url"], identity["official_website"]), "Official evidence must match the retained website; controller resolves parent/domain changes")
    else:
        require(identity["official_website"] is None and a["qualification"] == "verify_later", "Unresolved identity cannot assert official website or final qualification")
        require(not research["roles"], "Unresolved identity cannot retain verified roles")
    q, grade = a["qualification"], a["rating"]
    if policy["mode"] == "qualification_only":
        require(grade is None, "Qualification-only task must not assign a letter rating")
    else:
        require(grade is not None, "Rating task needs a rating or pending_research")
        expected = "no_go" if grade == "C" else "verify_later" if grade == "pending_research" else "target"
        require(q == expected, "Rating and qualification conflict")
    if q == "verify_later":
        require(bool(a["gaps"]) and all(text(g) for g in a["gaps"]) and text(a["next_check"]), "Pending decision needs concrete gaps and next_check")
    else:
        require(identity["status"] == "confirmed" and text(research["company_profile"]), "Final decision needs confirmed identity and company profile")
        types = {e["claim_type"] for e in evidence}
        require(("exclusion" if q == "no_go" else "relevance") in types, "Decision lacks business/exclusion evidence")
    if grade in {"A+", "A", "A-", "B+"}:
        types = {e["claim_type"] for e in official}
        require({"relevance", "cooperation"} <= types, "High-priority rating needs official relevance and cooperation facts")
        if grade == "A+":
            require("capacity" in types, "A+ needs demonstrated capacity/reach")
    if q == "no_go":
        require(bool(policy["exclusions"]), "Exclusion requires an explicit controller policy")
        require(contacts["status"] == "not_collected" and not contacts["routes"] and not contacts["checks"], "Final exclusion stops contact collection")
    else:
        require(contacts["status"] != "not_collected" and bool(contacts["checks"]), "Non-excluded result needs a recorded contact check or access limitation")
    for check in contacts["checks"]:
        require(text(check["trace"]) and text(check["note"]), "Contact attempts need actual endpoint/query and note")
    routes = contacts["routes"]
    require((contacts["status"] == "found") == bool(routes), "Contact status and route list conflict")
    seen = set()
    for r in routes:
        require(identity["status"] == "confirmed" and on_site(r["source_url"], identity["official_website"]), "Routes require a confirmed official source")
        require(text(r["value"]) and text(r["evidence"]), "Routes require exact public value and evidence")
        key = (r["type"], r["value"])
        require(key not in seen, "Duplicate route")
        seen.add(key)
        if r["type"] == "generic_email":
            require(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", r["value"]) is not None, "Invalid email")
        elif r["type"] == "generic_phone":
            require(len(re.sub(r"\D", "", r["value"])) >= 5, "Invalid phone")
        else:
            require(on_site(r["value"], identity["official_website"]), "Route URL must be on the official site")
    if research["research_status"] != "complete":
        require(bool(a["gaps"]) and text(a["next_check"]), "Partial/blocked research needs a recovery pointer")

def receipt_for(result_id, run_id, company_id, research, received_at):
    routes = research["contacts"]["routes"]
    return {"result_id": result_id, "run_id": run_id, "company_id": company_id,
            "task_status": "completed" if research["research_status"] == "complete" else "review",
            "rating": research["assessment"]["rating"], "qualification": research["assessment"]["qualification"],
            "contact_route_status": research["contacts"]["status"], "company_route_count": len(routes),
            "commercially_usable_route_count": sum(r["commercial_quality"] == "usable" for r in routes),
            "received_at": received_at, "validation": "passed",
            "independent_acceptance": "pending", "production_accepted": False}

def receive(path, run_id, company_id, research):
    with closing(open_db(path)) as c, c:
        c.execute("BEGIN IMMEDIATE")
        task, policy = assignment(c, run_id, company_id)
        validate(research, task, policy)
        canonical = packed(research)
        old = c.execute("SELECT research,receipt FROM results WHERE run_id=? AND company_id=?", (run_id, company_id)).fetchone()
        if old:
            require(old["research"] == canonical, "Conflicting repeat submission; controller must create a new run for a revision")
            return json.loads(old["receipt"])
        now = datetime.now(timezone.utc).isoformat()
        cur = c.execute("INSERT INTO results(run_id,company_id,research,received_at,receipt) VALUES(?,?,?,?,?)", (run_id, company_id, canonical, now, "{}"))
        receipt = receipt_for(cur.lastrowid, run_id, company_id, research, now)
        c.execute("UPDATE results SET receipt=? WHERE result_id=?", (packed(receipt), cur.lastrowid))
    return receipt

def readback(path, run_id, company_id):
    with closing(open_db(path)) as c:
        task, policy = assignment(c, run_id, company_id)
        row = c.execute("SELECT * FROM results WHERE run_id=? AND company_id=?", (run_id, company_id)).fetchone()
        require(row is not None, "No saved result")
        research, receipt = json.loads(row["research"]), json.loads(row["receipt"])
        validate(research, task, policy)
        expected = receipt_for(row["result_id"], run_id, company_id, research, row["received_at"])
        require(receipt == expected, "Receipt does not match persisted research")
        return {"accepted_structure": True, "receipt": receipt, "assignment": task, "research": research}

def next_task(path, run_id):
    with closing(open_db(path)) as c:
        policy = c.execute("SELECT policy FROM runs WHERE run_id=?", (run_id,)).fetchone()
        require(policy is not None, "Unknown run")
        row = c.execute("SELECT a.company_id,a.task FROM assignments a LEFT JOIN results r USING(run_id,company_id) WHERE a.run_id=? AND r.result_id IS NULL ORDER BY a.position LIMIT 1", (run_id,)).fetchone()
        return {"run_id": run_id, "next": None if row is None else {"assignment": json.loads(row["task"]), "policy": json.loads(policy["policy"])}}

def status(path, run_id):
    with closing(open_db(path)) as c:
        require(c.execute("SELECT 1 FROM runs WHERE run_id=?", (run_id,)).fetchone(), "Unknown run")
        assigned = c.execute("SELECT COUNT(*) FROM assignments WHERE run_id=?", (run_id,)).fetchone()[0]
        receipts = [json.loads(r[0]) for r in c.execute("SELECT receipt FROM results WHERE run_id=?", (run_id,))]
    return {"run_id": run_id, "assigned": assigned, "submitted": len(receipts), "remaining": assigned-len(receipts),
            "submission_complete": assigned == len(receipts), "independent_acceptance": "pending",
            "production_accepted": False, "results": receipts}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    for name in ("prepare", "next", "submit", "readback", "status"):
        cmd = sub.add_parser(name)
        cmd.add_argument("--db", required=True)
        if name == "prepare":
            cmd.add_argument("--input", required=True)
        else:
            cmd.add_argument("--run-id", required=True)
        if name in {"submit", "readback"}:
            cmd.add_argument("--company-id", required=True)
        if name == "submit":
            cmd.add_argument("--research", required=True)
    a = p.parse_args()
    try:
        if a.command == "prepare":
            result = prepare(a.db, json.loads(Path(a.input).read_text(encoding="utf-8-sig")))
        elif a.command == "submit":
            result = receive(a.db, a.run_id, a.company_id, json.loads(Path(a.research).read_text(encoding="utf-8-sig")))
        else:
            fn = {"next": next_task, "readback": readback, "status": status}[a.command]
            result = fn(a.db, a.run_id, a.company_id) if a.command == "readback" else fn(a.db, a.run_id)
        print(json.dumps(result, ensure_ascii=False))
    except (ValueError, OSError, sqlite3.Error) as exc:
        print(json.dumps({"status": "rejected", "error": str(exc), "production_accepted": False}, ensure_ascii=False))
        raise SystemExit(2)

if __name__ == "__main__":
    main()
