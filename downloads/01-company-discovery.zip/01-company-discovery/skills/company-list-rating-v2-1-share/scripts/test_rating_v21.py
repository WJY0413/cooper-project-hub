"""Offline receiver tests; all companies and pages below are synthetic."""
import copy
import json
import sqlite3
from contextlib import closing
import tempfile
import unittest
from pathlib import Path
import rating_v21 as r

def batch(n=1, mode="rating"):
    return {"run_id":"test","policy":{"mode":mode,"target_definition":"Professional equipment partners","exclusions":["Unrelated business"]},
            "companies":[{"company_id":str(i),"company_name":f"Synthetic {i}","official_website":f"https://c{i}.example","country_or_region":"GB","source_mappings":[{"row":i}],"restrictions":[]} for i in range(n)]}

def form(i=0):
    url=f"https://c{i}.example"
    return {"identity":{"status":"confirmed","company_name":f"Synthetic {i}","official_website":url},
      "company_profile":"Synthetic machinery dealer fixture, not a real company.",
      "roles":["dealer"],"assessment":{"rating":"B+","qualification":"target","reason":"Relevant equipment and service capability.","gaps":[],"next_check":None},
      "evidence":[{"claim_type":k,"fact":f"Synthetic {k} evidence","source_url":url,"source_kind":"official"} for k in ("identity","relevance","cooperation")],
      "contacts":{"status":"found","checks":[{"trace":url+"/contact","outcome":"read","note":"Synthetic contact fixture"}],
                  "routes":[{"type":"contact_page","value":url+"/contact","source_url":url+"/contact","evidence":"Company contact page","commercial_quality":"usable"},
                            {"type":"generic_email","value":f"sales@c{i}.example","source_url":url+"/contact","evidence":"Published company sales address","commercial_quality":"usable"}]},
      "research_status":"complete"}

class ReceiverTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Path(self.tmp.name)/"ledger.sqlite"
        self.b=batch()
        r.prepare(self.db,self.b)
    def tearDown(self):
        self.tmp.cleanup()
    def submit(self,f=None):
        return r.receive(self.db,"test","0",form() if f is None else f)
    def rejected(self,f):
        with self.assertRaises(ValueError): self.submit(f)
        self.assertEqual(r.status(self.db,"test")["submitted"],0)
    def test_same_page_supports_distinct_facts(self):
        self.submit()
        a=r.readback(self.db,"test","0")
        self.assertTrue(a["accepted_structure"])
        self.assertEqual(a["receipt"]["independent_acceptance"],"pending")
        self.assertFalse(a["receipt"]["production_accepted"])
    def test_idempotency_and_conflict(self):
        first=self.submit()
        self.assertEqual(first,self.submit())
        f=form(); f["company_profile"]+=" changed"
        with self.assertRaises(ValueError): self.submit(f)
        self.assertEqual(r.readback(self.db,"test","0")["receipt"],first)
    def test_wrong_company_binding(self):
        self.rejected(form(1))
    def test_cross_domain_route(self):
        f=form(); f["contacts"]["routes"][0]["source_url"]="https://other.example/contact"
        self.rejected(f)
    def test_cross_domain_identity(self):
        f=form(); f["identity"]["official_website"]="https://other.example"
        self.rejected(f)
    def test_no_go_stops_routes(self):
        f=form(); f["assessment"].update(rating="C",qualification="no_go")
        f["evidence"].append({"claim_type":"exclusion","fact":"Unrelated business","source_url":"https://c0.example","source_kind":"official"})
        self.rejected(f)
        f["contacts"]={"status":"not_collected","checks":[],"routes":[]}
        self.assertEqual(self.submit(f)["rating"],"C")
    def test_unsupported_no_go(self):
        f=form(); f["assessment"].update(rating="C",qualification="no_go")
        f["contacts"]={"status":"not_collected","checks":[],"routes":[]}
        self.rejected(f)
    def test_pending_confirmed_business(self):
        f=form(); f["assessment"].update(rating="pending_research",qualification="verify_later",gaps=["Dealer role unknown"],next_check="Check brand authorization")
        self.assertEqual(self.submit(f)["qualification"],"verify_later")
    def test_unresolved_identity(self):
        f=form(); f["identity"].update(status="unresolved",official_website=None)
        f["roles"]=[]; f["evidence"]=[]
        f["assessment"].update(rating="pending_research",qualification="verify_later",gaps=["Identity unknown"],next_check="Resolve legal name")
        f["contacts"]={"status":"blocked","checks":[{"trace":"Exact-name search","outcome":"blocked","note":"No attributable official domain"}],"routes":[]}
        f["research_status"]="blocked"
        self.assertEqual(self.submit(f)["task_status"],"review")
    def test_missing_contact_does_not_lower_rating(self):
        f=form(); f["contacts"]={"status":"not_found","checks":[{"trace":"https://c0.example/contact","outcome":"not_found","note":"No public contact route found"}],"routes":[]}
        self.assertEqual(self.submit(f)["rating"],"B+")
    def test_non_sales_does_not_count_usable(self):
        f=form()
        for x in f["contacts"]["routes"]: x["commercial_quality"]="non_sales"
        self.assertEqual(self.submit(f)["commercially_usable_route_count"],0)
    def test_missing_contact_check(self):
        f=form(); f["contacts"]["checks"]=[]
        self.rejected(f)
    def test_metadata_not_model_owned(self):
        f=form(); f["production_accepted"]=True
        self.rejected(f)
    def test_no_fabricated_top_tier(self):
        f=form(); f["assessment"]["rating"]="A+"
        self.rejected(f)
    def test_no_pending_without_next_check(self):
        f=form(); f["assessment"].update(rating="pending_research",qualification="verify_later")
        self.rejected(f)
    def test_qualification_only(self):
        b=batch(mode="qualification_only"); b["run_id"]="qualification"
        r.prepare(self.db,b)
        with self.assertRaises(ValueError): r.receive(self.db,"qualification","0",form())
        f=form(); f["assessment"]["rating"]=None
        self.assertIsNone(r.receive(self.db,"qualification","0",f)["rating"])
    def test_existing_run_immutable(self):
        self.assertTrue(r.prepare(self.db,self.b)["replayed"])
        b=batch(); b["policy"]["target_definition"]="different"
        with self.assertRaises(ValueError): r.prepare(self.db,b)
    def test_resume_with_50_companies(self):
        b=batch(50); b["run_id"]="fifty"
        r.prepare(self.db,b)
        r.receive(self.db,"fifty","0",form())
        self.assertEqual(r.next_task(self.db,"fifty")["next"]["assignment"]["company_id"],"1")
        self.assertEqual(r.status(self.db,"fifty")["remaining"],49)
    def test_wrong_assignment_not_written(self):
        with self.assertRaises(ValueError): r.receive(self.db,"test","unknown",form())
        self.assertEqual(r.status(self.db,"test")["submitted"],0)
    def test_independent_readback_detects_receipt_tampering(self):
        self.submit()
        with closing(sqlite3.connect(self.db)) as c, c: c.execute("UPDATE results SET receipt='{}'")
        with self.assertRaises(ValueError): r.readback(self.db,"test","0")
    def test_foreign_database_untouched(self):
        foreign=Path(self.tmp.name)/"production.sqlite"
        with closing(sqlite3.connect(foreign)) as c, c: c.execute("CREATE TABLE company(id INTEGER)")
        before=foreign.read_bytes()
        with self.assertRaises(ValueError): r.prepare(foreign,self.b)
        self.assertEqual(before,foreign.read_bytes())
    def test_atomic_rejection_keeps_neighbor(self):
        b=batch(2); b["run_id"]="two"; r.prepare(self.db,b)
        r.receive(self.db,"two","0",form())
        f=form(1); f["assessment"]["rating"]="unexpected"
        with self.assertRaises(ValueError): r.receive(self.db,"two","1",f)
        self.assertTrue(r.readback(self.db,"two","0")["accepted_structure"])
        self.assertEqual(r.status(self.db,"two")["remaining"],1)

if __name__=="__main__":
    unittest.main()
