---
name: bd-source-direction-finder-share
description: Build the user-style BD source-direction maps for overseas companylist discovery. Use when the user asks for 开发方向, 找方向, 线索方向, 挖掘思路, 哪些方向重点, source direction, channel/source pool, or gives examples such as Segway代理, 展会清单, 代理名单, 经销商网络, 协会目录, 竞品生态, tender/framework winner lists. The output is source pools, direction-quality ranking, and extraction routes for companylists; broad market demand scenes are converted into list-bearing source pools.
---

# BD Source Direction Finder

## Purpose

Use this skill before lead mining when the user is asking where the next usable companylist can come from. Treat "direction" as a source pool that can produce a list of companies, contacts, dealers, service providers, distributors, installers, contractors, or channel partners.

## Trigger Fit

Use this skill for requests such as:
- "先找方向"
- "开发方向是什么"
- "有哪些可挖的 company list"
- "像 Segway 代理、展会清单这种方向"
- "Google Map 之外还有什么挖掘思路"
- "先别找具体公司，先找来源方向"

## Workflow

1. Restate the target in one line: product, region, channel objective, and that the deliverable is source directions.
2. Choose the mode: direction-quality discussion, source-direction map, or approved companylist mining handoff.
3. For direction-quality discussion, rank directions from the quality rubric below. Keep existing company rows, local files, row counts, memories, and workbook ratings out of the answer unless the user asks for an audit of prior work.
4. Build a direction map from reusable source pools. Load `references/source-pool-taxonomy.md` when examples are useful.
5. Score each direction for list availability, buyer/channel immediacy, recurring demand, channel leverage, extraction efficiency, and expected lead quality.
6. Return only directions unless the user explicitly asks to start mining company names.
7. For any current website, directory, event, dealer locator, or member list, verify live because lists and exhibitors drift.

## Direction-Quality Mode

When the user asks "which directions are important", "哪个方向重点", "方向质量", or similar, answer from commercial direction quality rather than from what has already been mined.

Use this rubric:
- Buyer/channel immediacy: the target already buys, sells, uses, or services related equipment.
- Recurring or multi-site demand: the target controls repeated line-marking work across many pitches, sites, contracts, or customers.
- Channel leverage: one company can reach many grounds teams, contractors, schools, councils, clubs, or facilities.
- Source-list strength: the direction has visible locators, member directories, exhibitor lists, supplier categories, tender awards, or searchable service pages.
- Conversion path: the outreach angle is clear, such as replacement, second machine, reseller, demo partner, referral partner, or service-efficiency buyer.
- Competitive friction: existing Turf Tank, TinyMobileRobots, or exclusive distributor relationships are flagged as risk, while non-exclusive adjacent channels stay attractive.
- Extraction efficiency: a first companylist can be produced with clean source evidence and limited manual interpretation.

Use prior files, memories, already-mined companies, row counts, and workbook ratings only for explicit audit prompts such as "基于已有名单", "过往已经挖了什么", "检查本地文件", or "哪些已经做过". In audit mode, separate two conclusions: direction quality and completion status.

## Output Format

Use a concise Chinese table with these columns:

| 优先级 | 来源方向 | 可产出的公司类型 | 为什么适合 | 第一挖掘入口 | 验证门槛 |
| --- | --- | --- | --- | --- | --- |

Keep each row actionable. A good row names a source pool and the kind of companylist it can produce.

## Source Direction Types

Prefer directions that expose an existing list, locator, exhibitor roster, member directory, award list, framework list, or searchable supplier category.

Core source pools:
- Brand/dealer networks: robotic mower, line marker, groundcare, turf equipment, amenity machinery, car park marking equipment.
- Exhibition and conference rosters: exhibitor lists, sponsor lists, floorplans, speaker/company pages.
- Association and member directories: trade bodies, contractor associations, sports turf bodies, parking/highway marking groups.
- Competitor and adjacent-product ecosystems: robot dealers, GPS line-marking service providers, paint suppliers, grounds maintenance contractors.
- Tender, framework, and procurement lists: awarded contractors, approved suppliers, public-sector frameworks.
- Trade media and vertical directories: dealer directories, product-category pages, buyer guides, publication advertisers.
- Importer/distributor signals: exclusive distributor pages, warranty/service center locators, installation partner pages.

## Quality Gate

A direction is valid when it has:
- A visible or searchable source pool.
- A clear company type to extract.
- A plausible connection to the user's channel goal.
- A first query or first website to test.
- A short verification rule for deciding whether it deserves companylist mining.

If a direction is only an end-market scene, label it as market context and convert it into a list-bearing source pool before presenting it as a development direction.

## Handoff

When the user approves one or more directions, pass the chosen direction to the bundled [company-discovery skill](../general-list-mining-v2-1-share/SKILL.md), using the supplied scope. Requested ratings use the bundled rating policy. Do not assume access to a private business database.
