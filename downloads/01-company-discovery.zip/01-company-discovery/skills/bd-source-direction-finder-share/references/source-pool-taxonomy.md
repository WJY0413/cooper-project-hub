# Source Pool Taxonomy

Use this reference when the user asks for direction discovery before companylist mining.

## Direction Patterns

| Pattern | Typical Inputs | List Output | First Search Angle |
| --- | --- | --- | --- |
| Brand dealer networks | Segway, Husqvarna, Kress, STIHL, Ambrogio, Mammotion, Echo | Dealers, service centers, installers, regional distributors | brand + dealer locator + country |
| Exhibition rosters | SALTEX, GroundsFest, BTME, Highways UK, Parkex, Intertraffic | Exhibitors, sponsors, product-category suppliers | event + exhibitor list + year |
| Association directories | GMA, BIGGA, BAGMA, SAPCA, RSMA, Amenity Forum | Members, contractors, dealers, service companies | association + members directory |
| Competitor ecosystem | Turf Tank, TinyMobileRobots, GPS line marking, robotic mowing | Service providers, distributors, resellers, fleet operators | competitor + dealer, distributor, partner, case study |
| Adjacent suppliers | line marking paint, transfer wheel markers, amenity chemicals, turf care machinery | Suppliers, dealers, contractors with matching customer access | product category + suppliers + country |
| Tender and framework lists | councils, schools, sports grounds, highways, parking | Awarded contractors, approved suppliers, facilities contractors | procurement award + framework + category |
| Trade media directories | Service Dealer, Pitchcare, Garden Trader, Highway Industry Product Guide | Advertisers, listed dealers, category suppliers | publication + directory + category |
| Importer or warranty signals | exclusive distributor, authorized repair, service partner | Importers, wholesalers, aftersales networks | brand + authorized service + country |

## Scoring Heuristic

Score each direction from 1 to 5:

- 5: Existing list with strong channel fit and easy extraction.
- 4: Existing list with moderate cleanup.
- 3: Searchable pool with mixed relevance.
- 2: Useful context that needs conversion into a list-bearing source.
- 1: Weak source signal with unclear extraction path.

Rank source directions by commercial quality, not by prior row count or already-mined coverage. For "which directions are key" questions, favor directions with direct buyer/channel immediacy, recurring multi-site demand, channel leverage, strong source-list availability, a clear conversion path, and efficient extraction.

Use existing companylists or local project files only when the task is explicitly about auditing previous work. In that case, report completion status separately from direction priority.

## Development-Direction Row Template

| 优先级 | 来源方向 | 可产出的公司类型 | 为什么适合 | 第一挖掘入口 | 验证门槛 |
| --- | --- | --- | --- | --- | --- |
| P1 | [source pool] | [company type] | [channel logic] | [first query or site] | [what proves it can produce a list] |
