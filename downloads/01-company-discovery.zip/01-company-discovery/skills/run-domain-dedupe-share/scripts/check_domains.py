"""Bounded read-only batch membership in a supplied run index, not history lookup."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
from urllib.parse import urlsplit
import uuid


MAX_INDEX_BYTES = 16 * 1024 * 1024
TOOL_VERSION = "1.0.0"


def normalized_domain(value):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("domains must be nonempty strings")
    value = value.strip().lower()
    parsed = urlsplit(value if "://" in value else "//" + value)
    if parsed.scheme and parsed.scheme not in ("http", "https"):
        raise ValueError("unsupported domain URL scheme")
    if parsed.username or parsed.password or not parsed.hostname:
        raise ValueError("invalid domain")
    domain = parsed.hostname.rstrip(".")
    if domain.startswith("www."):
        domain = domain[4:]
    domain = domain.encode("idna").decode("ascii")
    if len(domain) > 253 or "." not in domain or any(
        not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
        for label in domain.split(".")
    ):
        raise ValueError("invalid domain")
    return domain


def domain_lookup(path, domains, receipt_dir):
    # Read at most limit + 1 even if a file grows after opening; never serialize
    # PowerShell's extended Get-Content string or enumerate provider metadata.
    with path.open("rb") as stream:
        raw = stream.read(MAX_INDEX_BYTES + 1)
    if len(raw) > MAX_INDEX_BYTES:
        raise ValueError("domain index exceeds 16 MiB input limit")
    data = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(data, dict) or not isinstance(data.get("known_prior_domains"), list):
        raise ValueError("index requires known_prior_domains string array")
    known = {normalized_domain(item) for item in data["known_prior_domains"]}
    requested = [normalized_domain(item) for item in domains]
    results = [{"input_index": pos, "input": original, "normalized_domain": domain,
                "matched": domain in known} for pos, (original, domain) in enumerate(zip(domains, requested))]
    receipt_dir.mkdir(parents=True, exist_ok=True)
    check_id = "run-domain-" + str(uuid.uuid4())
    receipt_path = (receipt_dir / (check_id + ".json")).resolve()
    receipt = {"schema_version": "run-domain-dedupe-receipt/v1", "tool_version": TOOL_VERSION,
               "check_id": check_id, "status": "completed", "scope": "run_index",
               "checked_at": datetime.now(timezone.utc).isoformat(), "inputs": domains,
               "results": results, "index_path": str(path.resolve()),
               "index_sha256": hashlib.sha256(raw).hexdigest(),
               "note": "Supplied run-index membership only, not global history, object identity, or business acceptance. This code is not a signature."}
    # Exclusive fresh filename; only advertise success after flushing this owned
    # receipt. Never overwrite another task's receipt or accept a caller's code.
    created = False
    try:
        with receipt_path.open("x", encoding="utf-8") as stream:
            created = True
            json.dump(receipt, stream, ensure_ascii=True, separators=(",", ":"))
            stream.flush()
            os.fsync(stream.fileno())
    except OSError:
        if created:
            receipt_path.unlink(missing_ok=True)
        raise
    return {"status": "completed", "check_id": check_id, "receipt_path": str(receipt_path), "results": results}



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--domain-index", type=Path, required=True)
    parser.add_argument("--domains", nargs="+", required=True)
    parser.add_argument("--receipt-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = domain_lookup(args.domain_index, args.domains, args.receipt_dir)
    except (OSError, ValueError, TypeError, RecursionError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=True))
        raise SystemExit(1)
    print(json.dumps(result, ensure_ascii=True))
