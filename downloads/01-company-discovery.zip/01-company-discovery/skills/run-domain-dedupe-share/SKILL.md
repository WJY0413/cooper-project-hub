---
name: run-domain-dedupe-share
description: Batch-check candidate domains against a supplied run index with bounded input reads and a saved unique check receipt. Use for current-run mining deduplication, not Workbench historical lookup or object identity decisions.
---

# Run Domain Dedupe

Use the bundled tool, not a handwritten PowerShell read/serialize pipeline:

```powershell
python skills/run-domain-dedupe-share/scripts/check_domains.py --domain-index <index.json> --receipt-dir <this-task-receipts-directory> --domains example.com other.example
```

Batch one discovery wave per invocation. The short-lived standard-library tool reads
the index once (maximum 16 MiB), parses UTF-8/BOM JSON directly, and returns compact
per-input normalized domain membership, a unique `check_id`, and `receipt_path`.
Index schema: `{"known_prior_domains":["example.com"]}`. Protocol/path and leading
`www` are removed; remaining subdomains stay distinct. Do not reread the full index
per company or launch a persistent MCP for this operation. Never pipe
`Get-Content -Raw` into `ConvertTo-Json` (PowerShell 5.1 expands attached metadata).

A nonzero exit or `status=error` is unresolved, not a miss, and has no successful
check code. Successful code issuance means the check completed and its receipt
was flushed to disk; it does not mean no duplicates were found. Preserve the code
and receipt path in the task's permitted output. This does not write the run index
or a business database.

The receiving controller must read the actual saved receipt, check its schema,
`status=completed`, `scope=run_index`, check ID, exact ordered `inputs` and per-input
mapping against the submitted candidates, and index path/SHA256 against the intended
index snapshot. Changed inputs or a different snapshot require a new check. A bare
worker-written code is insufficient; the UUID is neither authentication nor a
cryptographic signature. A later changed index does not invalidate the fact that
an older snapshot was checked, but cannot serve as proof for the new snapshot.

Same domain may represent different venues/projects/branches. A run-index hit is
not automatic same-object exclusion, and a miss is not global historical novelty.
Use Workbench domain-history lookup separately when the assignment requires it.
Retain tool session IDs until exit; cancel/wait for your owned command on failure,
never abandon yielded processes or terminate other tasks. The read bound is not
a general Jarvis process-tree memory limit.
