---
name: general-list-mining-v2-1-share
description: Batch discovery of official company domains with evidence-backed qualification or requested ratings. Use built-in Web, run-domain-dedupe and a persistent keyword library to optimize yield and rotate exhausted queries within the assigned geography and target types.
---

# General List Mining V2.1

Find previously unspecified targets from the user's criteria. Deliver confirmed official domains and concise supporting official evidence; add ratings only when requested, using the assignment's rating policy. Keep uncertain cases separate. This skill does not authorize contact mining, production admission or outreach.

## Assignment and research

- Preserve the supplied geography, object types, output boundary, budget and deadline. For systematic coverage, track region × target type and distinguish observed companies from completed coverage.
- Start with list-bearing sources, then regional or service-language searches for genuine gaps. Directories and snippets identify leads; company-controlled pages support qualification and requested ratings.
- Use built-in **Web search/open** for online research. Do not use CUA, Chrome/Edge, the in-app browser, Playwright or another frontend-browser route. An inaccessible dynamic directory becomes an access gap; choose another official source within scope. Do not spend the research turn building browser/search infrastructure.
- Batch independent searches and candidate checks. Save multiple companies in a turn where sources support it; no arbitrary company/query quota is a completion condition. Read only enough official evidence for the requested deliverable, not a company dossier.

## Current-run domain deduplication

From the unpacked package root, read and use the bundled [run-domain-dedupe skill](../run-domain-dedupe-share/SKILL.md). This is the required tool for supplied run-index checks; **do not write replacement Python/PowerShell/JavaScript dedupe code**, copy its implementation, introduce a persistent MCP, or fall back to a handwritten read/serialize pipeline.

For each discovery wave, before repeating website research, invoke the existing script once with the candidate domains:

```powershell
python skills/run-domain-dedupe-share/scripts/check_domains.py --domain-index <provided-index.json> --receipt-dir <allowed-output-directory/receipts> --domains example.com other.example
```

- The index contract is `{"known_prior_domains":["example.com"]}`. The tool bounds reads to 16 MiB, handles UTF-8/BOM, and normalizes URLs while keeping non-www subdomains distinct. Do not reread the index for every company or pipe `Get-Content -Raw` into `ConvertTo-Json`.
- Save the returned `check_id` and `receipt_path` alongside the associated ordered candidate inputs. A completed receipt can contain hits; successful execution does not mean every domain is new.
- Nonzero exit, `status=error`, missing index or invalid input means **dedupe unresolved**, never a miss. Preserve valid findings as pending, report the exact error to the controller, and proceed with independent work. Do not invent a check code or implement a fallback checker.
- Keep the tool session ID until exit. Await or cancel only your owned command when necessary; never abandon yielded processes or terminate other workers.
- Reuse a check only for the same ordered inputs and index snapshot. Changed inputs or an intended new snapshot require a fresh tool invocation.

### Controller receipt acceptance

Read the actual tool-written receipt. Verify schema, `status=completed`, `scope=run_index`, check ID, ordered `inputs`, each input/result mapping, and index path/SHA256 against the intended snapshot. A worker-written UUID alone is not proof. An older valid receipt proves only its recorded snapshot; index changes do not rewrite that history.

A hit means supplied-index membership, not automatic entity duplication. Preserve distinct branches, venues or projects sharing a domain when relevant. A miss is **not** global historical novelty, business qualification or permission to contact.

## Historical lookup is separate

When required, the controller batches historical checks through the separately approved read-only history interface. Workers do not scan business databases or create history tools. `run-domain-dedupe` must not be described as a Workbench/BDdb lookup. Unavailable historical capability remains `history_pending`; it does not prevent saving a real official domain and its evidence.

## Save findings and continue

Follow the assigned schema. Default fields: name, type, region, official_domain, evidence_url, evidence_excerpt, qualification_reason, run_dedupe_check_id, run_dedupe_receipt_path, history_status and gaps. Include rating/rating_reason only if requested; for company ratings use the provided policy or [company-list-rating-v2-1](../company-list-rating-v2-1-share/SKILL.md) as the applicable reference. Domain-plus-official-evidence rating assignments do not require a full V2.1 sidecar or personal contacts.

Save incremental results in the permitted directory. JSONL uses actual newlines between complete JSON objects, not literal `\\n` separators; write snapshots atomically with existing project utilities where available. Keep originals and source lineage. Mechanical field/format defects are isolated and corrected from saved facts, never by fabricating evidence; one failed item does not stop the whole direction.

Reuse your latest summary, prior findings, keyword library and check receipts. Apply the yield rules below. Do not sleep, wait for the deadline, or emit empty continuation turns. A deadline is the latest stop, not a time to fill. Search failures are capability gaps, not proof of an empty market.

## Keyword library and yield optimization

Maintain `keyword_library.jsonl` in the assigned output directory; it is a durable ledger of actual searches, not a speculative list of words. Read the latest compact summary and relevant library entries before searching. Preserve earlier entries across thread changes. Reuse known productive combinations for uncovered cells; do not repeat exhausted combinations without a concrete new source, changed access or new company evidence.

- A wave is a coherent batch of searches and candidate checks in one source direction. Several waves may run within one turn; the three-wave rule is not a three-turn limit and must not be evaded by renaming the same searches.
- Append one entry per actually executed query or enumerated source slice. Record `wave_id`, `thread_id`, `searched_at` (with timezone), `region`, `target_type`, `language`, exact `query` or `source_url` plus page/filter, `source_family`, `status`, candidate domains, linked dedupe check IDs/receipt paths, saved result references and gaps. Never invent queries, tool executions or historical performance.
- A wave summary records raw candidates, run-index hits, distinct supported new-to-run domains, requested rating coverage, supporting official evidence coverage, high-value objects under the supplied policy, unresolved checks, tool failures and next direction. Attribute a domain once per wave and once in cumulative totals; hits, placeholders and directories are not new output. A new domain lacking a requested rating may be saved but is not a complete domain-plus-rating delivery.
- Where native usage is available, the controller links per-wave or per-turn API-equivalent cost and cost per supported new domain / complete requested deliverable. Keep request time, result-save time and actual billing distinct; unavailable costs stay unknown. Workers do not repeatedly scan native logs or invoke another model just to calculate metrics.
- After **three consecutive successfully executed waves with zero supported new-to-run domains** in a direction, immediately change the keyword combination or source family within scope. Vary uncovered county/city, local service wording, relevant partner type, brand/dealer network or procurement/member roster; choose a genuinely unsearched combination, not a cosmetic rewrite. Switch sooner when recorded duplicate rates and falling relevant yield already show saturation. Do not lower evidence or relevance requirements to increase yield.
- Tool errors and unresolved dedupe are technical uncertainty, not evidence of source exhaustion; record separately and pursue an independent accessible source. Distinct entities sharing a domain remain separate when the assignment requires entity coverage, but do not inflate domain yield.
- If genuinely different accessible source families also produce no additions and no unsearched in-scope source remains, record covered combinations, access gaps and remaining coverage cells, then end normally. Do not claim the market is empty or the entire region is covered. Changing threads alone does not refresh an exhausted source.

The library is updated from real execution as work proceeds. The controller may merge worker ledgers after a batch with source/thread attribution intact; avoid concurrent edits to a shared library. Suggested statuses: `productive`, `duplicate_only`, `no_supported_new`, `technical_unresolved`, `exhausted`. Status and next-action choices must be backed by the recorded wave outcomes.

## Controller handoff

Report raw candidates, unique supported objects, new-to-run objects, run-index hits, unresolved checks, requested rating coverage, sources covered and stop reason separately. Do not call raw domains net-new qualified partners. Preserve old results across thread changes.

This share edition runs one user-assigned research task at a time. It does not include Jarvis, worker dispatch, automatic continuation or cost-collection integrations. Stop at the requested scope, budget or a genuine source limitation; do not launch workers automatically.
