# 销售资料库自建包

这份包让同事用自己的资料和账号，建立知识库、料号库、价格库，并让 AI 协助操作自己的 Odoo。包含一个 Skill、实际空 SQLite 库、来源配置模板和飞书只读刷新脚本。默认没有任何企业业务数据、源链接或账号。

## 开始使用

1. 解压到自己的工作目录。将 `skills/sales-library-workspace` 文件夹复制到所用 AI 客户端的 skills 目录；Codex 常用位置为用户目录下 `.codex/skills/`。若已有同名 Skill，先比较和备份，不直接覆盖。
2. 用 AI 打开解压目录并调用 `$sales-library-workspace`。也可以让支持读取 Markdown 的 AI 直接阅读该目录下的 SKILL.md。
3. 安装 Python 3.10+ 后，在包目录运行 `python scripts/library.py status`。应显示七张表全部为 0。包已带空库，无需再次 init；另建一个库可用 `python scripts/library.py init --db data/my-library.sqlite`，后续命令同样加 `--db`。
4. 把 `config/sources.example.json` 复制为 `config/sources.json`，填写自己的来源；Odoo 用户把 `config/odoo.example.json` 复制为 `config/odoo.json`，让 AI 根据实际实例补充配置。配置中不放密码或登录凭证。
5. 配置飞书来源后，使用自己的 `lark-cli` 登录环境运行 `python scripts/library.py refresh --source YOUR_SOURCE_ID`。具体格式见 Skill 的 references/sources.md。CLI 的安装与登录由使用者环境提供，本包不代办授权。

可以直接发给 AI：

> 使用 $sales-library-workspace，从这个目录的空库开始。先检查我提供的资料与已登录系统，协助绑定知识、料号和价格来源，再验证一次读取。Odoo 先做只读能力检查，列出可用的查询和单据操作。不要导入示例业务数据。

## 四个模块

| 模块 | 能做什么 | 使用者需提供什么 |
|---|---|---|
| 知识库 | 整理原文摘要、索引和来源版本 | 自己的知识文档或目录 |
| 料号库 | 记录产品、地区变体、搭配规则、停用状态 | 权威产品主表 |
| 价格库 | 按市场、币种、档位和有效期核对价格 | 有权使用的价目表/报价目录 |
| Odoo | 查询客户、产品、价格、库存；准备与执行已授权的单据操作；回读核验 | 自己的实例权限、字段映射和企业模板 |

源快照刷新和业务入库是两步。飞书刷新脚本可执行；PDF 解析、字段映射和结构化入库由 AI 结合真实资料完成。Odoo 部分是可执行的 agent 工作流程，依赖当前环境已有连接器或浏览器，没有捆绑通用 Odoo API 写入程序。

更新方式是使用时按需读取，不包含后台定时任务。每位同事必须拥有原库权限。原文更新之后，结构化记录也需要重新核验；旧缓存不能冒充最新价格。复制 ZIP 本身不会产生自动同步服务。

请先在自己的测试资料与 Odoo 测试环境验收，再授权生产操作。不要将填入真实数据后的工作目录重新当作空包转发。
